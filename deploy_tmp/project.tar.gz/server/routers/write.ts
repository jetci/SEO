// EEAT Studio V2 · Write tRPC Router — Phase 2D Write Pipeline (10 Steps: 5-10)
// Replaces PHASE1 STUB => now wires ArticleWriterService to generate EEAT 1500+ word drafts.
// 3 Procedures: write.createDraft, write.getDraft, write.publish
// Status: write_articles workflow 10-step, articles.status draft/published FK
import { z } from 'zod';
import { router } from '../_core/trpc.js';
import { protectedProcedure, TRPCError, type ProtectedCtx } from '../_core/middleware/rbac.js';
import { eq, and, desc, sql } from 'drizzle-orm';
import { db } from '../../db/index.js';
import { articles, clusters, keywords as keywordsTable, projects as projectsTable, categories as categoriesTable, researchPackages as rpTable, users, writeArticles } from '../../db/schema.js';
import { assertProjectAccess } from './_projectAccess.js';
import ArticleWriterService, { type ResearchPackageLite } from '../services/articleWriterService.js';
import { resolveTeamIdForSettings, resolveTeamSettings } from './settings.js';
import { PROVIDER_DEFAULT_MODELS } from '../services/llmClient.js';
import * as crypto from 'node:crypto';
import { Document, Packer, Paragraph, HeadingLevel, TextRun } from 'docx';

function extractInsertId(res: any): number {
  if (Array.isArray(res)) {
    if (res.length > 0 && typeof res[0]?.insertId === 'number') return Number(res[0].insertId);
    if (typeof (res as any).insertId === 'number') return Number((res as any).insertId);
    const first = (res as any)[0];
    if (first && typeof first === 'object') {
      if (typeof (first as any).insertId === 'number') return Number((first as any).insertId);
      if (Array.isArray(first) && typeof first[0]?.insertId === 'number') return Number(first[0].insertId);
    }
  } else if (res && typeof (res as any).insertId === 'number') return Number((res as any).insertId);
  return 0;
}

function serverParseInlineRuns(line: string, extraOpts?: { italics?: boolean }): TextRun[] {
  const runs: TextRun[] = [];
  const tokens = line.split(/(\*\*[^*\n]+\*\*|`[^`\n]+`)/g);
  const italicBase = !!(extraOpts?.italics);
  for (const tok of tokens) {
    if (!tok) continue;
    const boldMatch = tok.match(/^\*\*([^*\n]+)\*\*$/);
    const codeMatch = tok.match(/^`([^`\n]+)`$/);
    if (boldMatch) runs.push(new TextRun({ text: boldMatch[1], bold: true, italics: italicBase }));
    else if (codeMatch) runs.push(new TextRun({ text: codeMatch[1], font: "Courier New", size: 20, italics: italicBase }));
    else runs.push(new TextRun({ text: tok, italics: italicBase }));
  }
  return runs.length ? runs : [new TextRun({ text: "", italics: italicBase })];
}

function serverMarkdownToDocxParagraphs(md: string): Paragraph[] {
  const lines = String(md ?? "").split(/\r?\n/);
  const paras: Paragraph[] = [];
  let inCodeBlock = false;
  let codeBuf: string[] = [];
  const flushCode = () => {
    if (codeBuf.length) {
      for (const cl of codeBuf) paras.push(new Paragraph({ children: [new TextRun({ text: cl, font: "Courier New", size: 20 })], spacing: { before: 0, after: 0 } }));
      codeBuf = [];
    }
  };
  for (const raw of lines) {
    if (/^```/.test(raw)) { inCodeBlock ? (flushCode(), inCodeBlock = false) : (inCodeBlock = true); continue; }
    if (inCodeBlock) { codeBuf.push(raw); continue; }
    const h1 = raw.match(/^#\s+(.*)$/); if (h1) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: serverParseInlineRuns(h1[1]) })); continue; }
    const h2 = raw.match(/^##\s+(.*)$/); if (h2) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: serverParseInlineRuns(h2[1]) })); continue; }
    const h3 = raw.match(/^###\s+(.*)$/); if (h3) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: serverParseInlineRuns(h3[1]) })); continue; }
    const h4 = raw.match(/^####\s+(.*)$/); if (h4) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_4, children: serverParseInlineRuns(h4[1]) })); continue; }
    const bullet = raw.match(/^\s*[-*+]\s+(.*)$/); if (bullet) { flushCode(); paras.push(new Paragraph({ bullet: { level: 0 }, children: serverParseInlineRuns(bullet[1]) })); continue; }
    const quote = raw.match(/^>\s*(.*)$/);
    if (quote) { flushCode(); paras.push(new Paragraph({ children: serverParseInlineRuns(quote[1], { italics: true }), spacing: { before: 60, after: 60 } })); continue; }
    if (!raw.trim()) { flushCode(); paras.push(new Paragraph({ children: [new TextRun("")], spacing: { after: 100 } })); continue; }
    flushCode();
    paras.push(new Paragraph({ children: serverParseInlineRuns(raw) }));
  }
  flushCode();
  return paras;
}

async function serverGenerateDocxBuffer(md: string, titleText?: string): Promise<Buffer> {
  const children: Paragraph[] = [];
  if (titleText?.trim()) children.push(new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: titleText, bold: true })] }));
  children.push(...serverMarkdownToDocxParagraphs(md));
  const doc = new Document({ sections: [{ properties: {}, children }] });
  const arr = await Packer.toBuffer(doc);
  return Buffer.from(arr);
}

const NEW_UUID = () => crypto.randomUUID();

export const writeRouter = router({
  createDraft: protectedProcedure
    .input(z.object({ keywordId: z.number().int().positive(), force: z.boolean().default(false), model: z.string().max(120).optional() }))
    .mutation(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const selectedModel = String(input.model || "").trim() || undefined;
      const [kw] = await db.select({
        id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier,
        projectId: keywordsTable.projectId, categoryId: keywordsTable.categoryId, clusterId: keywordsTable.clusterId,
      }).from(keywordsTable).where(eq(keywordsTable.id, input.keywordId)).limit(1);
      if (!kw) throw new TRPCError({ code: 'NOT_FOUND', message: `Keyword ${input.keywordId} not found.` });
      // ── USER SIMPLIFY RULE: ทุก Pillar/Cluster/Supporting เขียนได้เดียวกัน ──
      // OLD BLOCKER REMOVED: Pillar tier no longer throws BAD_REQUEST
      if (!kw.projectId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] keyword missing project FK.' });
      await assertProjectAccess(ctx, Number(kw.projectId), { minRole: 'member' }, TRPCError);

      // Resolve author id safely: ctx.user can be NULL if user DB row not pre-hydrated into context
      // (per ProtectedCtx type user: User | null). Fallback: resolve via ctx.session.openId like other routers.
      const openId = String(ctx.session.openId || '').trim();
      let authorId: number = 0;
      if (ctx.user && typeof ctx.user.id === 'number' && Number.isFinite(ctx.user.id) && ctx.user.id > 0) {
        authorId = Number(ctx.user.id);
      } else if (openId) {
        const [userRow] = await db.select({ id: users.id }).from(users).where(eq(users.googleOpenId, openId)).limit(1);
        if (!userRow) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Author DB row not found for current session. Please sign in again.' });
        authorId = Number(userRow.id);
      } else {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Session missing openId. Please sign in.' });
      }
      const teamId = await resolveTeamIdForSettings(ctx);

      // Find cluster topic (parentId -> pillar / cluster self name / pillar self = keyword for pillar tier)
      let clusterTopic: string | null = null;
      if (kw.clusterId) {
        const [cl] = await db.select({ name: clusters.name, type: clusters.type }).from(clusters).where(eq(clusters.id, Number(kw.clusterId))).limit(1);
        if (cl) clusterTopic = cl.name;
      } else if (kw.tier === 'cluster' || kw.tier === 'pillar') {
        clusterTopic = kw.keywordText;
      }

      // Load research package: For pillar tier → use SELF pkg. For cluster/supporting → find pillar ancestor pkg first, fallback self
      let pkgLite: ResearchPackageLite = { keyword_text: kw.keywordText, serp_top10: [], paa_questions: [], ai_overview: '', citation_pool: [], is_ymyl: false, ymyldisclaimer_required: false, keyword_id: kw.id, project_id: kw.projectId };
      let ymyl = false;
      {
        let pillarKwId: number | undefined;
        if (kw.tier === 'pillar') {
          pillarKwId = kw.id;
        } else if (kw.clusterId) {
          const [pillarkw] = await db.select({ id: keywordsTable.id }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'pillar'), eq(keywordsTable.clusterId, Number(kw.clusterId)))).limit(1);
          if (pillarkw) pillarKwId = pillarkw.id;
        }
        const pkgKwId = pillarKwId ?? kw.id;
        const [pkgRow] = await db.select({ pkg: rpTable.packageJson, pkgid: rpTable.id }).from(rpTable).where(eq(rpTable.keywordId, pkgKwId)).limit(1);
        if (pkgRow?.pkg) {
          try {
            const parsed = typeof pkgRow.pkg === 'string' ? JSON.parse(pkgRow.pkg) : pkgRow.pkg;
            (pkgLite as any) = { ...pkgLite, ...(parsed ?? {}) };
            if (typeof pkgLite.keyword_text !== 'string' || !pkgLite.keyword_text) pkgLite.keyword_text = kw.keywordText;
            if (!Array.isArray(pkgLite.serp_top10)) pkgLite.serp_top10 = [];
            if (!Array.isArray(pkgLite.paa_questions)) pkgLite.paa_questions = [];
            if (!Array.isArray(pkgLite.citation_pool)) pkgLite.citation_pool = [];
          } catch { /* keep empty pkg fallback */ }
        }
        const [proj] = await db.select({ categoryId: projectsTable.categoryId }).from(projectsTable).where(eq(projectsTable.id, Number(kw.projectId))).limit(1);
        if (proj?.categoryId) {
          const [cat] = await db.select({ isYmyl: categoriesTable.isYmyl }).from(categoriesTable).where(eq(categoriesTable.id, Number(proj.categoryId))).limit(1);
          ymyl = !!cat?.isYmyl;
        }
      }

      // Return existing draft if force=false and already exists (ALL tiers including pillar)
      if (!input.force) {
        const [existing] = await db.select({
          artId: articles.id, title: articles.title, status: articles.status, content: articles.content, metaTitle: articles.metaTitle, metaDescription: articles.metaDescription, categoryId: articles.categoryId,
          writeStep: writeArticles.writeStep, stepStatus: writeArticles.stepStatus, wordCount: writeArticles.wordCount, eeatScore: writeArticles.eeatScore, disclaimerAdded: writeArticles.disclaimerAdded, citationsCount: writeArticles.citationsCount, writeId: writeArticles.id,
        }).from(articles).innerJoin(writeArticles, eq(writeArticles.articleId, articles.id)).where(and(eq(articles.projectId, Number(kw.projectId)), eq(articles.keywordId, kw.id))).limit(1);
        if (existing && existing.status === 'draft') {
          return { ok: true, traceId, phase2Ready: true, draft_id: existing.artId, write_article_id: existing.writeId, from_existing: true, title: existing.title, content: existing.content, word_count_total: existing.wordCount, citations_count: existing.citationsCount, eeat_score: existing.eeatScore, disclaimer_added: !!existing.disclaimerAdded, ymyl_required: ymyl, status: existing.status, write_step: existing.writeStep, step_status: existing.stepStatus };
        }
      }

      // Acquire project author ctx.userId
      const categoryId = kw.categoryId ? Number(kw.categoryId) : (await db.select({ cid: projectsTable.categoryId }).from(projectsTable).where(eq(projectsTable.id, Number(kw.projectId))).limit(1)).at(0)?.cid ?? 1;

      let pkgInsertId: number | undefined;
      {
        const [rprow] = await db.select({ id: rpTable.id }).from(rpTable).where(eq(rpTable.keywordId, kw.id)).limit(1);
        pkgInsertId = rprow?.id;
      }

      // ============================================================
      // ⭐⭐⭐⭐⭐ MENU #1 STREAMING WRITE P0 CRITICAL: 3 NEW CONTEXT INJECT
      // ============================================================
      // C1: 3-TIER KEYWORD CONTEXT (Pillar → Cluster → Supporting hierarchy sibling keywords)
      //     Pillar tier self-write: pillar_keyword_text = self, cluster_siblings = all tier=cluster same project, supporting_peers = all tier=supporting children of those clusters
      type TierCtx = { pillar_keyword_text: string | null; cluster_siblings: string[]; supporting_peers: string[] };
      const threeTierCtx: TierCtx = { pillar_keyword_text: null, cluster_siblings: [], supporting_peers: [] };
      try {
        if (kw.tier === 'pillar') {
          // PILLAR TIER: pillar_keyword_text = self, cluster_siblings = all tier=cluster same project limit 10, supporting_peers = all tier=supporting same project limit 20
          threeTierCtx.pillar_keyword_text = kw.keywordText;
          if (kw.projectId) {
            const clAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'cluster'))).limit(10);
            threeTierCtx.cluster_siblings = clAll.map(r => r.t).filter(Boolean);
            const spAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'supporting'))).limit(20);
            threeTierCtx.supporting_peers = spAll.map(r => r.t).filter(Boolean);
          }
        } else if (kw.projectId && kw.clusterId) {
          // Cluster / Supporting tier with clusterId → standard hierarchy same cluster
          const [pillarr] = await db.select({ text: keywordsTable.keywordText }).from(keywordsTable)
            .where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'pillar'), eq(keywordsTable.clusterId, Number(kw.clusterId))))
            .limit(1);
          if (pillarr?.text) threeTierCtx.pillar_keyword_text = pillarr.text;
          const clSibs = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable)
            .where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'cluster'), eq(keywordsTable.clusterId, Number(kw.clusterId))))
            .limit(20);
          threeTierCtx.cluster_siblings = clSibs.map(r => r.t).filter(t => t && t !== kw.keywordText).slice(0, 10);
          const spPeers = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable)
            .where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'supporting'), eq(keywordsTable.clusterId, Number(kw.clusterId))))
            .limit(30);
          threeTierCtx.supporting_peers = spPeers.map(r => r.t).filter(t => t && t !== kw.keywordText).slice(0, 15);
        } else if (kw.projectId) {
          // No clusterId yet: fallback global project-level hierarchy
          const clAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'cluster'))).limit(8);
          const spAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'supporting'))).limit(15);
          threeTierCtx.cluster_siblings = clAll.map(r => r.t).filter(Boolean);
          threeTierCtx.supporting_peers = spAll.map(r => r.t).filter(Boolean);
          const pillAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kw.projectId)), eq(keywordsTable.tier, 'pillar'))).limit(1);
          if (pillAll[0]?.t) threeTierCtx.pillar_keyword_text = pillAll[0].t;
        }
      } catch { /* ignore context query errors keep fallback empty */ }

      // C2: OUTLINE OVERRIDE FROM STEP 2 (if user already generated H1..H6 via AI Outline Editor cur===1)
      let outlineOverride: any = null;
      try {
        // FIRST try write_articles.outlineJson row for this existing article (draft existing already opened in editor)
        if (kw.projectId) {
          const [existingArt] = await db.select({ id: articles.id }).from(articles)
            .where(and(eq(articles.projectId, Number(kw.projectId)), eq(articles.keywordId, kw.id))).limit(1);
          if (existingArt?.id) {
            const [waRow] = await db.select({ o: writeArticles.outlineJson }).from(writeArticles)
              .where(eq(writeArticles.articleId, Number(existingArt.id))).limit(1);
            if (waRow?.o) {
              const parsed = typeof waRow.o === 'string' ? JSON.parse(waRow.o) : waRow.o;
              if (parsed && Array.isArray(parsed.sections) && parsed.sections.length >= 3) outlineOverride = parsed;
            }
          }
        }
        // SECOND fallback: check keywords.outline_json custom column if exists (NO ALTER, skip safely)
      } catch { /* keep null fallback uses static buildOutline default */ }

      // C3: DENSITY TARGETS — Build main/longtail/LSI keyword list from cluster with 2% ceiling max
      const densityTargets = {
        main_keywords: [kw.keywordText],
        longtail_keywords: ([] as string[]).concat(threeTierCtx.cluster_siblings.slice(0, 6)).filter((v, i, a) => a.indexOf(v) === i),
        lsi_keywords: ([] as string[]).concat(threeTierCtx.supporting_peers.slice(0, 12)).filter((v, i, a) => a.indexOf(v) === i),
        max_pct: 2.0,
      };

      // Write workflow step 5: mark running
      const start = Date.now();

      // Generate draft using service (INJECT 3 NEW CONTEXTS: tier hierarchy + step2 outline + density targets)
      const out = await ArticleWriterService.writeDraft(ctx, pkgLite, clusterTopic, ymyl, Number(kw.projectId), threeTierCtx, outlineOverride, densityTargets);
      const durationMs = Date.now() - start;

      // Insert articles row + write_articles workflow row, upsert duplicate keyword
      let articleId: number;
      const [existingArt] = await db.select({ id: articles.id }).from(articles).where(and(eq(articles.projectId, Number(kw.projectId)), eq(articles.keywordId, kw.id))).limit(1);
      const d = out.draft;
      if (existingArt) {
        await db.update(articles).set({
          title: d.title, metaTitle: d.meta_title, metaDescription: d.meta_description,
          content: out.markdown_content, categoryId, status: 'draft', updatedAt: new Date(), authorId: Number(authorId),
        }).where(eq(articles.id, existingArt.id));
        articleId = existingArt.id;
      } else {
        const ins = await db.insert(articles).values({
          projectId: Number(kw.projectId), keywordId: kw.id, authorId: Number(authorId), categoryId,
          title: d.title, metaTitle: d.meta_title, metaDescription: d.meta_description,
          content: out.markdown_content, status: 'draft',
        });
        articleId = extractInsertId(ins);
        if (!articleId) {
          const [sel] = await db.select({ id: articles.id }).from(articles).where(and(eq(articles.projectId, Number(kw.projectId)), eq(articles.keywordId, kw.id))).limit(1);
          if (sel) articleId = sel.id;
        }
      }
      if (!articleId) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Failed to persist articles row (no insertId returned).' });

      // Update keyword written status
      await db.update(keywordsTable).set({ status: 'written' }).where(eq(keywordsTable.id, kw.id));

      // Persist write_articles workflow row step 8 = done draft + eeat_score
      const outlineJsonStr = JSON.stringify(out.outline);
      const clusterIdOrNull = kw.clusterId ? Number(kw.clusterId) : null;
      try {
        await db.insert(writeArticles).values({
          articleId,
          researchPackageId: pkgInsertId,
          clusterId: clusterIdOrNull,
          teamId,
          wordCount: Number(out.word_count_total),
          outlineJson: outlineJsonStr,
          disclaimerAdded: out.disclaimer_added ? 1 : 0,
          eeatScore: Math.min(100, Math.max(0, out.eeat_score_est)),
          citationsCount: Number(out.citations_count_total),
          writeStep: 8,
          stepStatus: 'done',
          errorMsg: null,
        }).onDuplicateKeyUpdate({
          set: {
            writeStep: 8, stepStatus: 'done', wordCount: Number(out.word_count_total),
            eeatScore: Math.min(100, Math.max(0, out.eeat_score_est)),
            citationsCount: Number(out.citations_count_total), disclaimerAdded: out.disclaimer_added ? 1 : 0,
            outlineJson: outlineJsonStr, researchPackageId: pkgInsertId, errorMsg: null, updatedAt: new Date(),
          },
        });
      } catch (e: any) {
        console.warn('[write.createDraft] write_articles upsert fail:', String(e?.message ?? e).slice(0, 220));
      }

      return {
        ok: true, traceId, phase2Ready: true, from_existing: false,
        draft_id: articleId,
        write_article_id: 0,
        duration_ms: durationMs,
        title: d.title,
        meta: { meta_title: d.meta_title, meta_description: d.meta_description },
        content: out.markdown_content,
        word_count_total: out.word_count_total,
        eeat_score: Math.min(100, Math.max(0, out.eeat_score_est)),
        citations_count: out.citations_count_total,
        disclaimer_added: out.disclaimer_added,
        ymyl_required: out.ymyl_required,
        write_step: 8,
        step_status: 'done',
      };
    }),

  getDraft: protectedProcedure
    .input(z.object({ draftId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const [row] = await db.select({
        id: articles.id, title: articles.title, content: articles.content, status: articles.status,
        projectId: articles.projectId, keywordId: articles.keywordId, categoryId: articles.categoryId,
        metaTitle: articles.metaTitle, metaDescription: articles.metaDescription, authorId: articles.authorId,
        createdAt: articles.createdAt, updatedAt: articles.updatedAt,
        wa_id: writeArticles.id, wordCount: writeArticles.wordCount, eeatScore: writeArticles.eeatScore,
        disclaimerAdded: writeArticles.disclaimerAdded, citationsCount: writeArticles.citationsCount,
        writeStep: writeArticles.writeStep, stepStatus: writeArticles.stepStatus, errorMsg: writeArticles.errorMsg,
      }).from(articles).leftJoin(writeArticles, eq(writeArticles.articleId, articles.id)).where(eq(articles.id, input.draftId)).limit(1);
      if (!row) throw new TRPCError({ code: 'NOT_FOUND', message: `Draft ${input.draftId} not found.` });
      if (row.projectId) await assertProjectAccess(ctx, Number(row.projectId), { minRole: 'member' }, TRPCError);

      // ── 3-TIER CLUSTER CONTEXT (KCP → Write Page Context Passing) ──
      // When user clicks เขียน from KCP → editor sidebar shows Pillar/Cluster/Supporting hierarchy + peer keywords in same cluster (H1/H2/H3 placements) so user knows what to write.
      let cluster_context: any = null;
      try {
        if (row.keywordId) {
          const [focusKw] = await db.select({
            id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier, clusterId: keywordsTable.clusterId,
            intentSuggestion: keywordsTable.intentSuggestion, difficulty: keywordsTable.difficulty, searchVolume: keywordsTable.searchVolume,
          }).from(keywordsTable).where(eq(keywordsTable.id, Number(row.keywordId))).limit(1);
          if (focusKw) {
            let siblings: any[] = [];
            let clusterName: string | null = null;
            let clusterId: number | null = null;
            if (focusKw.clusterId) {
              clusterId = Number(focusKw.clusterId);
              siblings = await db.select({
                id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier, intentSuggestion: keywordsTable.intentSuggestion,
              }).from(keywordsTable).where(eq(keywordsTable.clusterId, clusterId)).orderBy(keywordsTable.tier, keywordsTable.id).limit(100);
              const [clsRow] = await db.select({ name: clusters.name }).from(clusters).where(eq(clusters.id, clusterId)).limit(1);
              clusterName = clsRow?.name ?? null;
            }
            let pillarKw: any = null;
            const pillars = await db.select({
              id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier, clusterId: keywordsTable.clusterId,
            }).from(keywordsTable).where(and(
              eq(keywordsTable.projectId, Number(row.projectId)),
              eq(keywordsTable.tier, 'pillar' as any),
            )).limit(20);
            if (pillars.length) {
              if (clusterId) {
                const samePillar = pillars.find(p => p.clusterId === clusterId);
                pillarKw = samePillar ?? pillars[0];
              } else {
                pillarKw = pillars[0];
              }
            }
            cluster_context = {
              focus_keyword: { id: focusKw.id, keyword: focusKw.keywordText, tier: focusKw.tier, intent: focusKw.intentSuggestion, kd: focusKw.difficulty, sv: focusKw.searchVolume },
              cluster: clusterId ? { id: clusterId, name: clusterName } : null,
              same_cluster_keywords: siblings.map(s => ({ id: s.id, keyword: s.keywordText, tier: s.tier, intent: s.intentSuggestion })),
              pillar_keyword: pillarKw ? { id: pillarKw.id, keyword: pillarKw.keywordText, tier: pillarKw.tier } : null,
              project_id: row.projectId,
            };
          }
        }
      } catch (e: any) {
        console.warn("[getDraft] cluster_context fetch best-effort skipped:", String(e?.message ?? e).slice(0, 100));
        cluster_context = null;
      }

      return {
        ok: true,
        draft: {
          id: row.id, title: row.title, content: row.content, status: row.status, keyword_id: row.keywordId,
          category_id: row.categoryId, project_id: row.projectId, author_id: row.authorId,
          meta_title: row.metaTitle ?? '', meta_description: row.metaDescription ?? '',
          created_at: row.createdAt, updated_at: row.updatedAt,
        },
        workflow: row.wa_id ? {
          write_article_id: row.wa_id, word_count: row.wordCount, eeat_score: row.eeatScore,
          disclaimer_added: !!row.disclaimerAdded, citations_count: row.citationsCount,
          write_step: row.writeStep, step_status: row.stepStatus, error_msg: row.errorMsg ?? null,
        } : null,
        cluster_context,
      };
    }),

  publish: protectedProcedure
    .input(z.object({ draftId: z.number().int().positive(), unpublish: z.boolean().default(false) }))
    .mutation(async ({ ctx, input }) => {
      const [row] = await db.select({ id: articles.id, projectId: articles.projectId, status: articles.status }).from(articles).where(eq(articles.id, input.draftId)).limit(1);
      if (!row) throw new TRPCError({ code: 'NOT_FOUND', message: `Draft ${input.draftId} not found.` });
      if (!row.projectId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] article row orphan.' });
      await assertProjectAccess(ctx, Number(row.projectId), { minRole: 'admin' }, TRPCError);
      const targetStatus = input.unpublish ? 'draft' : 'published';
      await db.update(articles).set({ status: targetStatus, updatedAt: new Date() }).where(eq(articles.id, input.draftId));
      try {
        await db.update(writeArticles).set({
          writeStep: input.unpublish ? 9 : 10,
          stepStatus: 'done',
          updatedAt: new Date(),
        }).where(eq(writeArticles.articleId, input.draftId));
      } catch { /* ignore */ }
      return {
        ok: true,
        draft_id: input.draftId,
        new_status: targetStatus,
        message: targetStatus === 'published' ? '✅ บทความตีพิมพ์สำเร็จ (EEAT verified workflow step 10)' : 'บทความย้อนกลับเป็นฉบับร่างแล้ว',
        write_step: targetStatus === 'published' ? 10 : 9,
      };
    }),

  listByProject: protectedProcedure
    .input(z.object({ projectId: z.number().int().positive(), limit: z.number().int().positive().max(100).default(20), status: z.enum(['draft','published']).optional() }))
    .query(async ({ ctx, input }) => {
      await assertProjectAccess(ctx, input.projectId, { minRole: 'member' }, TRPCError);
      const where: any[] = [eq(articles.projectId, input.projectId)];
      if (input.status) where.push(eq(articles.status, input.status));
      const rows = await db.select({
        id: articles.id, title: articles.title, status: articles.status, keywordId: articles.keywordId,
        updatedAt: articles.updatedAt, authorId: articles.authorId,
        wordCount: writeArticles.wordCount, eeatScore: writeArticles.eeatScore,
      }).from(articles).leftJoin(writeArticles, eq(writeArticles.articleId, articles.id)).where(and(...where)).orderBy(desc(articles.updatedAt)).limit(input.limit);
      return { ok: true, count: rows.length, items: rows };
    }),

  saveDraft: protectedProcedure
    .input(z.object({
      draftId: z.number().int().positive(),
      title: z.string().max(500).optional(),
      content: z.string().max(200000).optional(),
      metaTitle: z.string().max(200).optional().or(z.null()),
      metaDescription: z.string().max(600).optional().or(z.null()),
      wordCount: z.number().int().min(0).max(500000).optional(),
      eeatScore: z.number().int().min(0).max(100).optional(),
      citationsCount: z.number().int().min(0).max(1000).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const [row] = await db.select({
        id: articles.id, projectId: articles.projectId, status: articles.status, authorId: articles.authorId,
      }).from(articles).where(eq(articles.id, input.draftId)).limit(1);
      if (!row) throw new TRPCError({ code: 'NOT_FOUND', message: `Draft ${input.draftId} not found.` });
      if (!row.projectId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] article orphan row.' });
      await assertProjectAccess(ctx, Number(row.projectId), { minRole: 'member' }, TRPCError);

      const updates: any = {};
      if (typeof input.title === 'string') updates.title = input.title;
      if (typeof input.content === 'string') updates.content = input.content;
      if (typeof input.metaTitle !== 'undefined') updates.metaTitle = input.metaTitle;
      if (typeof input.metaDescription !== 'undefined') updates.metaDescription = input.metaDescription;
      updates.updatedAt = new Date();

      if (Object.keys(updates).length > 0) {
        await db.update(articles).set(updates).where(eq(articles.id, input.draftId));
      }

      // Upsert write_articles workflow step tracking (no ALTER SQL: reuse cols)
      const waUpdates: any = {};
      if (typeof input.wordCount === 'number') waUpdates.wordCount = input.wordCount;
      if (typeof input.eeatScore === 'number') waUpdates.eeatScore = Math.min(100, Math.max(0, input.eeatScore));
      if (typeof input.citationsCount === 'number') waUpdates.citationsCount = input.citationsCount;
      if (Object.keys(waUpdates).length > 0) {
        waUpdates.updatedAt = new Date();
        try {
          await db.insert(writeArticles).values({
            articleId: input.draftId,
            teamId: await resolveTeamIdForSettings(ctx),
            wordCount: waUpdates.wordCount ?? 0,
            eeatScore: waUpdates.eeatScore,
            citationsCount: waUpdates.citationsCount ?? 0,
            writeStep: 5,
            stepStatus: 'running',
          }).onDuplicateKeyUpdate({ set: waUpdates });
        } catch (e: any) {
          // fallback: old rows might exist — just update the existing one
          try {
            await db.update(writeArticles).set(waUpdates).where(eq(writeArticles.articleId, input.draftId));
          } catch (e2: any) {
            console.warn('[saveDraft] write_articles upsert+update both fail:', String(e2?.message || e2).slice(0, 120));
          }
        }
      }

      return {
        ok: true,
        traceId,
        draft_id: input.draftId,
        saved_at: new Date(),
        message: '✅ บันทึกสำเร็จ (workflow step 5 running editing)',
        changed_cols: Object.keys(updates).length + Object.keys(waUpdates).length,
      };
    }),

  delete: protectedProcedure
    .input(z.object({
      draftId: z.number().int().positive(),
    }))
    .mutation(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const [row] = await db.select({
        id: articles.id,
        projectId: articles.projectId,
        title: articles.title,
      }).from(articles).where(eq(articles.id, input.draftId)).limit(1);
      if (!row) throw new TRPCError({ code: 'NOT_FOUND', message: `บทความ id=${input.draftId} ไม่พบ` });
      if (!row.projectId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] article orphan row.' });
      await assertProjectAccess(ctx, Number(row.projectId), { minRole: 'member' }, TRPCError);
      const delWa = await db.delete(writeArticles).where(eq(writeArticles.articleId, input.draftId));
      const delArt = await db.delete(articles).where(eq(articles.id, input.draftId));
      const rowCount = Number((delArt as any)?.rowCount ?? (delArt as any)?.affectedRows ?? 0);
      return {
        ok: true,
        traceId,
        deleted_article_id: input.draftId,
        affected_rows: rowCount,
        deleted_workflow_rows: Number((delWa as any)?.rowCount ?? (delWa as any)?.affectedRows ?? 0),
        message: rowCount > 0 ? `✅ ลบบทความ #${input.draftId} เรียบร้อย (${String(row.title || '').slice(0, 60)})` : `⚠️ บทความ id=${input.draftId} ไม่พบเพื่อลบ`,
      };
    }),

  generateOutline: protectedProcedure
    .input(z.object({
      keywordId: z.number().int().positive().optional(),
      draftId: z.number().int().positive().optional(),
      force: z.boolean().default(false),
      model: z.string().max(120).optional(),
    }).refine(i => Number(i.keywordId ?? 0) > 0 || Number(i.draftId ?? 0) > 0, { message: 'keywordId หรือ draftId ต้องมีอย่างน้อย 1 ตัว' }))
    .mutation(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const teamSettings = await resolveTeamSettings(ctx);
      const runtimeProvider = String(teamSettings.llmProvider || 'openrouter').toLowerCase();
      // ── SANITIZE SELECTED MODEL: Cross-Provider ID prefix fix
      // OpenRouter = must have provider/model prefix (anthropic/xxx, openai/xxx, google/xxx)
      // Single Provider (openai/anthropic/google) = raw NO prefix (claude-xxx, gpt-xxx, gemini-xxx)
      function sanitizeModelId(selected: string | undefined, provider: string): string {
        const raw = String(selected || '').trim();
        const fallback = (PROVIDER_DEFAULT_MODELS as any)[provider] || (PROVIDER_DEFAULT_MODELS as any).openrouter;
        if (!raw) return fallback;
        // Single Provider → Strip "provider/" prefix if present
        if (provider !== 'openrouter' && raw.includes('/')) {
          const stripped = raw.split('/').slice(1).join('/');
          return stripped ? stripped : fallback;
        }
        // OpenRouter → NEEDS prefix; if missing prefix, fallback server default (avoid 400 Invalid Model)
        if (provider === 'openrouter' && !raw.includes('/')) return fallback;
        return raw;
      }
      const sanitizedModel = sanitizeModelId(input.model, runtimeProvider);
      let kwRow: any, projId: number | undefined, catId: number | undefined, draftRowRef: any = null;
      if (Number(input.draftId ?? 0) > 0) {
        const [r] = await db.select({
          id: articles.id, projectId: articles.projectId, categoryId: articles.categoryId, keywordId: articles.keywordId, title: articles.title, status: articles.status,
        }).from(articles).where(eq(articles.id, Number(input.draftId!))).limit(1);
        if (!r) throw new TRPCError({ code: 'NOT_FOUND', message: `draftId ${input.draftId} not found.` });
        draftRowRef = r;
        projId = Number(r.projectId);
        catId = Number(r.categoryId ?? 0) || undefined;
        const [kw] = await db.select({ id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier, projectId: keywordsTable.projectId, categoryId: keywordsTable.categoryId, clusterId: keywordsTable.clusterId }).from(keywordsTable).where(eq(keywordsTable.id, Number(r.keywordId ?? 0))).limit(1);
        kwRow = kw ?? { id: 0, keywordText: r.title ?? '(no keyword)', tier: 'supporting', projectId: projId, categoryId: catId, clusterId: 0 };
      } else {
        const [kw] = await db.select({ id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier, projectId: keywordsTable.projectId, categoryId: keywordsTable.categoryId, clusterId: keywordsTable.clusterId }).from(keywordsTable).where(eq(keywordsTable.id, Number(input.keywordId!))).limit(1);
        if (!kw) throw new TRPCError({ code: 'NOT_FOUND', message: `keywordId ${input.keywordId} not found.` });
        kwRow = kw;
        projId = Number(kw.projectId);
        catId = Number(kw.categoryId ?? 0) || undefined;
      }
      if (!projId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] keyword/project missing FK.' });
      await assertProjectAccess(ctx, Number(projId), { minRole: 'member' }, TRPCError);
      const teamId = await resolveTeamIdForSettings(ctx);

      // Existing outline lookup
      let existingOutline: any = null;
      if (draftRowRef && !input.force) {
        const [wa] = await db.select({ outline: writeArticles.outlineJson }).from(writeArticles).where(eq(writeArticles.articleId, Number(draftRowRef.id))).limit(1);
        if (wa?.outline) {
          try { existingOutline = typeof wa.outline === 'string' ? JSON.parse(wa.outline) : wa.outline; } catch { existingOutline = null; }
        }
      }

      const sectionSchema = z.object({ heading_level: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5), z.literal(6)]), heading_text: z.string().min(2).max(255), word_target_min: z.number().int().positive().default(200), key_points: z.array(z.string().min(0)).default([]) });
      const outSchema = z.object({ title: z.string().min(2).max(255).optional(), sections: z.array(sectionSchema).min(4) });

      function buildStaticOutline(kwText: string, serp: any[], faqs: any[], isYmyl: boolean): { title: string; sections: any[] } {
        const title = `คู่มือ ${kwText} ปี 2569 — ข้อมูลเชิงลึกทันสมัย มีหลักฐานอ้างอิง (EEAT)`;
        const faqH2 = faqs.slice(0, 3).map((p: any, i: number) => ({ heading_level: 2 as const, heading_text: `คำถามที่พบบ่อย ${i + 1}: ${String(p.question ?? 'FAQ').slice(0, 140)}`, word_target_min: 200, key_points: [String(p.snippet ?? 'คำตอบเชิงลึกอ้างอิงจาก SERP').slice(0, 200)] }));
        const sections: any[] = [
          { heading_level: 1, heading_text: title, word_target_min: 0, key_points: [] },
          { heading_level: 2, heading_text: `${kwText} คืออะไร? — บทนำและบริบท (Definition)`, word_target_min: 250, key_points: serp.slice(0, 3).map((r: any) => `SERP ประเด็นสำคัญ: ${String(r.title ?? '').slice(0, 180)}`) },
          { heading_level: 3, heading_text: `คำจำกัดความและประเภทของ ${kwText}`, word_target_min: 120, key_points: ['แบ่งประเภทตามเกณฑ์มาตรฐาน', 'ยกตัวอย่างชัดเจนแต่ละประเภท'] },
          { heading_level: 2, heading_text: `สาเหตุและปัจจัยสำคัญของ ${kwText} (Why / Causes)`, word_target_min: 250, key_points: ['ปัจจัยภายใน 3-5 ข้อ', 'ปัจจัยภายนอก 3-5 ข้ออ้างอิงสถิติ'] },
          { heading_level: 2, heading_text: `วิธีทำ / คู่มือปฏิบัติ ${kwText} สำหรับมือใหม่ (How-to Guide)`, word_target_min: 300, key_points: ['รายละเอียดทีละขั้นตอน 3-6 ขั้น', 'ข้อผิดพลาดที่พบบ่อย และวิธีแก้ไข', 'ตารางเปรียบเทียบ / Checklist พร้อมใช้งาน'] },
          { heading_level: 3, heading_text: `ขั้นตอน 1-3: เตรียมความพร้อม → ดำเนินการ → ตรวจสอบผลลัพธ์`, word_target_min: 120, key_points: ['เตรียมเครื่องมือ / ข้อมูลที่ต้องใช้', 'ดำเนินการตามขั้นตอน', 'ตรวจสอบและวัดผล'] },
          { heading_level: 3, heading_text: `ข้อผิดพลาดที่พบบ่อย ${kwText} และวิธีป้องกัน`, word_target_min: 120, key_points: ['5 ข้อผิดพลาดยอดนิยม', 'วิธีป้องกันและแก้ไขทันที'] },
          ...faqH2,
          { heading_level: 2, heading_text: `เปรียบเทียบ ${kwText} กับทางเลือกอื่น (Comparison / Case Study)`, word_target_min: 250, key_points: ['ตารางเปรียบเทียบ 3-5 ตัวเลือก', 'Case Study ผลลัพธ์จริงจาก SERP 3 ตัวอย่าง'] },
          isYmyl ? { heading_level: 2, heading_text: `ข้อควรระวัง / คำเตือนความเสี่ยง (YMYL Disclaimer ${kwText})`, word_target_min: 250, key_points: ['เงื่อนไขความเสี่ยง 5 ข้อ', 'ข้อจำกัด / ไม่รับประกันผลลัพธ์', 'ขอคำแนะนำจากผู้เชี่ยวชาญก่อนดำเนินการ'] } : null,
          { heading_level: 2, heading_text: `สรุปและคำแนะนำที่สำคัญ (Key Takeaways)`, word_target_min: 250, key_points: ['3-5 จุดเด่นที่ผู้อ่านควรจำ', 'ข้อเสนอแนะการดำเนินการต่อ 3 ขั้น', 'อ้างอิงแหล่งที่มาที่น่าเชื่อถือ'] },
        ].filter(Boolean);
        return { title, sections: sections.slice(0, 14) };
      }

      let catName = '';
      if (catId) {
        const [c] = await db.select({ name: categoriesTable.name }).from(categoriesTable).where(eq(categoriesTable.id, Number(catId))).limit(1);
        catName = c?.name ?? '';
      }
      const catNameTrim = String(catName || '').trim();
      const isCatYmyl = /(YMYL|คาสิโน|พนัน|สุขภาพ|การแพทย์|ยา|การเงิน|การลงทุน|หุ้น|กองทุน|ประกัน|สินเชื่อ)/i.test(catNameTrim);

      if (!existingOutline) {
        // Pkg evidence for context (pillar's research pkg if cluster/supporting)
        let serpTop10: any[] = [], paa: any[] = [], aiOverview = '';
        {
          let pillarKwId = Number(kwRow.id);
          if (kwRow.tier !== 'pillar' && kwRow.clusterId) {
            const [pkw] = await db.select({ id: keywordsTable.id }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(projId)), eq(keywordsTable.tier, 'pillar'), eq(keywordsTable.clusterId, Number(kwRow.clusterId ?? 0)))).limit(1);
            if (pkw) pillarKwId = Number(pkw.id);
          }
          const [pkgRow] = await db.select({ pkg: rpTable.packageJson }).from(rpTable).where(eq(rpTable.keywordId, pillarKwId)).limit(1);
          if (pkgRow?.pkg) {
            try {
              const p = typeof pkgRow.pkg === 'string' ? JSON.parse(pkgRow.pkg) : pkgRow.pkg;
              if (Array.isArray(p?.serp_top10)) serpTop10 = p.serp_top10.slice(0, 10);
              if (Array.isArray(p?.paa_questions)) paa = p.paa_questions.slice(0, 6);
              if (typeof p?.ai_overview === 'string') aiOverview = p.ai_overview.slice(0, 2400);
            } catch { /* ignore parse fail */ }
          }
        }
        // Fallback brand voice if any
        let bvPrelude = '';
        try {
          const { LlmService } = await import('../services/llmClient.js');
          const llm = await LlmService.forContext(ctx);
          const system = `You are a Thai/English SEO Outline Generator. STRICT JSON OUTPUT ONLY NO FENCES. Output {sections:[{heading_level:1-6, heading_text, word_target_min, key_points:string[]}]}. Language must match the keyword language (Thai if Thai characters present). HARD MINIMUM: sections.length ≥ 9. EXACT STRUCTURE MANDATORY: (1x H1 title), (5x-7x H2 sections), (2x-4x H3 subsections inside How-to/Causes). H1 heading_level=1 ONCE EXACT. H2 ≥ 5 sections FIXED ORDER LIST: Intro Definition → Causes/Factors → How-to Guide → FAQ → Comparison/Case Study → ${isCatYmyl ? 'YMYL Warning Section → ' : ''}Key Takeaways. Add H3 inside How-to (Steps + Common Mistakes) AND inside Causes (Factor Groups). Word targets: H2 ≥ 250 words, H3 ≥ 120 words. key_points = 2-5 actionable SERP-informed bullets per section that match intent (informational/commercial). NO markdown. NO trailing commas. ${isCatYmyl ? 'IMPORTANT YMYL CATEGORY: ADD EXTRA H2 SECTION "ข้อควรระวัง / คำเตือนความเสี่ยง" AFTER How-to BEFORE FAQ.' : ''}`;
          const user = `CATEGORY: ${catName || 'General'}\nKEYWORD: ${kwRow.keywordText}\nSERP TOP10 TITLES:\n${serpTop10.map((r, i) => `${i + 1}. ${r.title ?? ''}`).filter(Boolean).join('\n') || '(no SERP data yet — generate a general but authoritative outline)'}\n\nPEOPLE_ALSO_ASK:\n${paa.map((p, i) => `${i + 1}. ${p.question ?? ''}`).filter(Boolean).join('\n')}\n${aiOverview ? `\nSERP OVERVIEW SUMMARY:\n${aiOverview}` : ''}\n\nHARD NON-NEGOTIABLE RULES (VIOLATION = INVALID OUTLINE):\n1. MUST HAVE EXACTLY 1 HEADING_LEVEL=1 (H1) at index 0 of sections array\n2. H2 HEADING_LEVEL=2 COUNT = BETWEEN 5 AND 8 INCLUSIVE (never <5 never >8)\n3. H3 HEADING_LEVEL=3 COUNT = BETWEEN 2 AND 5 INCLUSIVE (at least 2 deep subsections, not 0!)\n4. FIXED H2 ORDER: [0:H1] → [1:Definition] → [2:Causes] → [3:How-to with H3 under it] → [4:Comparison/Case] → [${isCatYmyl ? '5:YMYL Warning → ' : ''}5/6:FAQ x1 or FAQ x3 H2s] → [last H2:Key Takeaways]\n5. FAQ: If PAA list >=3 then 3 H2 FAQ sections; else 1 H2 FAQ section.\n6. NEVER return only 2 sections. NEVER return sections without H1 (heading_level===1 count=0).\n7. word_target_min: H1=0, H2>=250, H3>=120.\n8. title field in root = SEO catchy H1 string 40-60 chars including keyword and year 2569.`;
          const parsed = await llm.chatStructured(system + (bvPrelude || ''), user, outSchema, { maxTokens: 4096, temperature: 0.2, model: sanitizedModel });
          existingOutline = { sections: Array.isArray(parsed?.sections) ? parsed.sections : [], title: parsed?.title ?? kwRow.keywordText };
          const secs: any[] = Array.isArray(existingOutline.sections) ? existingOutline.sections : [];
          const countH1 = secs.filter((s: any) => Number(s?.heading_level) === 1).length;
          const countH2 = secs.filter((s: any) => Number(s?.heading_level) === 2).length;
          const countH3 = secs.filter((s: any) => Number(s?.heading_level) === 3).length;
          const totalValid = secs.filter((s: any) => Number(s?.heading_level) >= 1 && Number(s?.heading_level) <= 6).length;
          const passed = (countH1 === 1) && (countH2 >= 5) && (countH3 >= 2) && (totalValid >= 9);
          if (!passed) {
            // HARD MIN EEAT GUARD FAILED → FALLBACK STATIC 8-12 sections NO EMPTY
            const staticBuilt = buildStaticOutline(kwRow.keywordText, serpTop10, paa, isCatYmyl);
            if (!existingOutline.title || /^\s*$/.test(String(existingOutline.title || ''))) existingOutline.title = staticBuilt.title;
            existingOutline.sections = staticBuilt.sections;
          }
        } catch (e: any) {
          const staticBuilt = buildStaticOutline(kwRow.keywordText, serpTop10, paa, isCatYmyl);
          existingOutline = staticBuilt;
        }
      }

      // Persist: upsert writeArticles if draftRowRef exists
      if (draftRowRef?.id) {
        const json = typeof existingOutline === 'string' ? existingOutline : JSON.stringify(existingOutline);
        try {
          await db.insert(writeArticles).values({ articleId: Number(draftRowRef.id), teamId, outlineJson: json, writeStep: 2, stepStatus: 'done', wordCount: 0 }).onDuplicateKeyUpdate({ set: { outlineJson: json, writeStep: 2, stepStatus: 'done', updatedAt: new Date() } });
        } catch (e2: any) { try { await db.update(writeArticles).set({ outlineJson: json, writeStep: 2, stepStatus: 'done', updatedAt: new Date() }).where(eq(writeArticles.articleId, Number(draftRowRef.id))); } catch {} }
      }
      return { ok: true, traceId, outline: existingOutline, persisted: !!draftRowRef?.id, sections_count: existingOutline?.sections?.length ?? 0 };
    }),

  rewriteSection: protectedProcedure
    .input(z.object({
      draftId: z.number().int().positive(),
      sectionHeading: z.string().min(1).max(500),
      currentText: z.string().min(1).max(50000),
      projectId: z.number().int().positive().optional(),
      threeTierCtx: z.object({
        pillar_keyword_text: z.string().max(500).nullable(),
        cluster_siblings: z.array(z.string().max(500)).default([]),
        supporting_peers: z.array(z.string().max(500)).default([]),
      }).optional().nullable(),
      densityTargets: z.object({
        main_keywords: z.array(z.string().max(500)).default([]),
        longtail_keywords: z.array(z.string().max(500)).default([]),
        lsi_keywords: z.array(z.string().max(500)).default([]),
        max_pct: z.number().min(0).max(20).default(2),
      }).optional().nullable(),
    }))
    .mutation(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const [artRow] = await db.select({
        id: articles.id, projectId: articles.projectId, keywordId: articles.keywordId, categoryId: articles.categoryId,
      }).from(articles).where(eq(articles.id, input.draftId)).limit(1);
      if (!artRow) throw new TRPCError({ code: 'NOT_FOUND', message: `Draft ${input.draftId} not found.` });
      const projId = Number(artRow.projectId ?? input.projectId ?? 0);
      if (!projId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] article orphan row.' });
      await assertProjectAccess(ctx, projId, { minRole: 'member' }, TRPCError);

      let kwRow: any = null;
      if (artRow.keywordId) {
        const [kw] = await db.select({
          id: keywordsTable.id, keywordText: keywordsTable.keywordText, tier: keywordsTable.tier,
          projectId: keywordsTable.projectId, clusterId: keywordsTable.clusterId,
        }).from(keywordsTable).where(eq(keywordsTable.id, Number(artRow.keywordId))).limit(1);
        kwRow = kw;
      }

      const keywordText = kwRow?.keywordText ?? input.sectionHeading.split(' ').slice(0, 3).join(' ');

      let threeTierCtx = input.threeTierCtx ?? null;
      if (!threeTierCtx && kwRow?.projectId) {
        threeTierCtx = { pillar_keyword_text: null, cluster_siblings: [], supporting_peers: [] };
        try {
          if (kwRow.clusterId) {
            const [pillarr] = await db.select({ text: keywordsTable.keywordText }).from(keywordsTable)
              .where(and(eq(keywordsTable.projectId, Number(kwRow.projectId)), eq(keywordsTable.tier, 'pillar'), eq(keywordsTable.clusterId, Number(kwRow.clusterId))))
              .limit(1);
            if (pillarr?.text) threeTierCtx.pillar_keyword_text = pillarr.text;
            const clSibs = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable)
              .where(and(eq(keywordsTable.projectId, Number(kwRow.projectId)), eq(keywordsTable.tier, 'cluster'), eq(keywordsTable.clusterId, Number(kwRow.clusterId))))
              .limit(20);
            threeTierCtx.cluster_siblings = clSibs.map(r => r.t).filter(t => t && t !== keywordText).slice(0, 10);
            const spPeers = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable)
              .where(and(eq(keywordsTable.projectId, Number(kwRow.projectId)), eq(keywordsTable.tier, 'supporting'), eq(keywordsTable.clusterId, Number(kwRow.clusterId))))
              .limit(30);
            threeTierCtx.supporting_peers = spPeers.map(r => r.t).filter(t => t && t !== keywordText).slice(0, 15);
          } else {
            const clAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kwRow.projectId)), eq(keywordsTable.tier, 'cluster'))).limit(8);
            const spAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kwRow.projectId)), eq(keywordsTable.tier, 'supporting'))).limit(15);
            threeTierCtx.cluster_siblings = clAll.map(r => r.t).filter(Boolean);
            threeTierCtx.supporting_peers = spAll.map(r => r.t).filter(Boolean);
            const pillAll = await db.select({ t: keywordsTable.keywordText }).from(keywordsTable).where(and(eq(keywordsTable.projectId, Number(kwRow.projectId)), eq(keywordsTable.tier, 'pillar'))).limit(1);
            if (pillAll[0]?.t) threeTierCtx.pillar_keyword_text = pillAll[0].t;
          }
        } catch { /* keep fallback empty */ }
      }

      let densityTargets = input.densityTargets ?? null;
      if (!densityTargets) {
        densityTargets = {
          main_keywords: [keywordText],
          longtail_keywords: threeTierCtx?.cluster_siblings?.slice(0, 6) ?? [],
          lsi_keywords: threeTierCtx?.supporting_peers?.slice(0, 12) ?? [],
          max_pct: 2.0,
        };
      }

      const out = await ArticleWriterService.rewriteSection(ctx, {
        sectionHeading: input.sectionHeading,
        currentText: input.currentText,
        keywordText,
        projectId: projId,
        threeTierCtx,
        densityTargets,
      });

      return {
        ok: true,
        traceId,
        draft_id: input.draftId,
        section_heading: input.sectionHeading,
        rewritten_text: out.rewritten_text,
        original_word_count: out.original_word_count,
        rewritten_word_count: out.rewritten_word_count,
      };
    }),

  setSchedule: protectedProcedure
    .input(z.object({
      draftId: z.number().int().positive(),
      scheduledAt: z.string().nullable().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const [artRow] = await db.select({
        id: articles.id, projectId: articles.projectId, status: articles.status,
      }).from(articles).where(eq(articles.id, input.draftId)).limit(1);
      if (!artRow) throw new TRPCError({ code: 'NOT_FOUND', message: `Draft ${input.draftId} not found.` });
      if (!artRow.projectId) throw new TRPCError({ code: 'BAD_REQUEST', message: '[NO_PROJECT_ID] article orphan row.' });
      await assertProjectAccess(ctx, Number(artRow.projectId), { minRole: 'member' }, TRPCError);

      if (input.scheduledAt) {
        const schedDt = new Date(input.scheduledAt);
        if (isNaN(schedDt.getTime())) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'scheduledAt รูปแบบวันที่ไม่ถูกต้อง (ต้องเป็น ISO datetime)' });
        }
        if (schedDt.getTime() <= Date.now() + 59_000) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'เวลาที่ตั้งต้องอยู่ในอนาคต (มากกว่า 1 นาทีข้างหน้า)' });
        }
      }

      const teamId = await resolveTeamIdForSettings(ctx);
      const [waRow] = await db.select({
        id: writeArticles.id, outlineJson: writeArticles.outlineJson,
      }).from(writeArticles).where(eq(writeArticles.articleId, input.draftId)).limit(1);

      let outline: any = {};
      if (waRow?.outlineJson) {
        try { outline = typeof waRow.outlineJson === 'string' ? JSON.parse(waRow.outlineJson) : waRow.outlineJson; }
        catch { outline = {}; }
      }

      if (input.scheduledAt) {
        const schedIso = new Date(input.scheduledAt).toISOString();
        outline.__scheduled_at = schedIso;
        if (outline.__published) delete outline.__published;
        if (outline.__published_at) delete outline.__published_at;
      } else {
        delete outline.__scheduled_at;
      }

      const outlineJsonStr = JSON.stringify(outline ?? {});
      try {
        if (waRow?.id) {
          await db.update(writeArticles).set({
            outlineJson: outlineJsonStr,
            updatedAt: new Date(),
          }).where(eq(writeArticles.id, Number(waRow.id)));
        } else {
          await db.insert(writeArticles).values({
            articleId: input.draftId,
            teamId,
            outlineJson: outlineJsonStr,
            wordCount: 0,
            writeStep: 8,
            stepStatus: 'done',
          }).onDuplicateKeyUpdate({ set: { outlineJson: outlineJsonStr, updatedAt: new Date() } });
        }
      } catch (e: any) {
        console.warn('[write.setSchedule] write_articles persist fail:', String(e?.message ?? e).slice(0, 200));
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'ไม่สามารถบันทึกตารางเวลาได้: ' + String(e?.message ?? e).slice(0, 200) });
      }

      return {
        ok: true,
        traceId,
        draft_id: input.draftId,
        scheduled_at: input.scheduledAt ? new Date(input.scheduledAt).toISOString() : null,
        action: input.scheduledAt ? 'set' : 'cancel',
        message: input.scheduledAt
          ? `✅ ตั้งเวลาเผยแพร่สำเร็จ (${new Date(input.scheduledAt).toLocaleString('th-TH')})`
          : '✅ ยกเลิกตารางเวลาเผยแพร่แล้ว',
      };
    }),

  exportDocx: protectedProcedure
    .input(z.object({ draftId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const traceId = NEW_UUID();
      const [row] = await db.select({
        id: articles.id, title: articles.title, content: articles.content, projectId: articles.projectId,
        metaTitle: articles.metaTitle,
      }).from(articles).where(eq(articles.id, input.draftId)).limit(1);
      if (!row) throw new TRPCError({ code: 'NOT_FOUND', message: `Draft ${input.draftId} not found.` });
      if (row.projectId) await assertProjectAccess(ctx, Number(row.projectId), { minRole: 'member' }, TRPCError);
      const buf = await serverGenerateDocxBuffer(String(row.content ?? ''), String(row.metaTitle ?? row.title ?? ''));
      return {
        ok: true,
        traceId,
        draft_id: row.id,
        base64: buf.toString('base64'),
        filename: `article_${row.id}_${Date.now()}.docx`,
        title: row.title ?? '',
      };
    }),
});

export default writeRouter;
