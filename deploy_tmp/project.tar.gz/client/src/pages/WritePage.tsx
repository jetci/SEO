import { useState, useEffect, useMemo, useRef } from "react";
import MainDashboardShell from "@/layouts/MainDashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Search, CheckCircle2, Sparkles, BookCheck, Eye, Save, AlertTriangle,
  FileDown, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, FileText, Type, ListOrdered,
  RefreshCw, Hash, Target, Loader2, Wand2, Plus, Minus, GripVertical,
  CalendarDays, Clock, X, Trash2, FileType, CheckCircle2 as CheckCircle2Icon,
} from "lucide-react";
import { Document, Packer, Paragraph, HeadingLevel, TextRun } from "docx";
import mammoth from "mammoth";
import { trpc } from "@/trpc";
import { useLocation, useRoute } from "wouter";
import { toast } from "sonner";
import useAuth from "@/hooks/useAuth";

type StepDef = { n: number; id: string; label: string; desc: string };

const STEPS: StepDef[] = [
  { n: 1, id: "input",    label: "ข้อมูลตั้งต้น",   desc: "Keyword + Intent + AI Model" },
  { n: 2, id: "outline",  label: "โครง + Sources", desc: "Outline H1/H2 + แหล่งอ้างอิง DA≥35" },
  { n: 3, id: "write",    label: "เขียนเนื้อหา",    desc: "เขียนทีละ Section" },
  { n: 4, id: "assemble", label: "รวม + Meta",     desc: "Meta Title + Description" },
  { n: 5, id: "review",   label: "ตรวจ/แก้ไข",     desc: "Density ≤2% + Inline Edit" },
  { n: 6, id: "preview",  label: "ดู + เก็บคลัง",  desc: "SERP preview + Export" },
];

// ── AI Model Catalog PER PROVIDER (FIX: dynamic from Settings Page saved llmProvider)
// OLD: hardcoded 3 mixed providers ignoring user actual saved API → WRONG: "โมเดลนี้ไม่ใช่โมเดลของ API ที่อยู่ในระบบตั้งค่า"
// NEW: Map llmProvider → list of models ACTUALLY SUPPORTED BY THAT PROVIDER ONLY
// Model IDs align exactly with server/services/llmClient.ts PROVIDER_DEFAULT_MODELS L20-25
type AIModelDef = { id: string; label: string; badge: string; cls: string; per1m: number };
type LLMProviderKey = "openrouter" | "openai" | "anthropic" | "google";
const PROVIDER_CATALOG: Record<LLMProviderKey, { name: string; accent: string; models: AIModelDef[]; defaultIdx: number }> = {
  // OpenRouter = multi-model gateway, user can pick any (this matches old 3 + gemini 2 flash default free)
  openrouter: {
    name: "OpenRouter (รวมหลาย Provider)",
    accent: "!bg-purple-50 !border-purple-200 text-purple-800",
    defaultIdx: 0,
    models: [
      { id: "google/gemini-2.0-flash-exp:free", label: "Gemini 2.0 Flash (Free Tier)",  badge: "ค่าเริ่มต้น", cls: "bg-purple-700", per1m: 0.075 },
      { id: "anthropic/claude-3.5-sonnet",     label: "Claude Sonnet (ไทยดี สมดุล)",     badge: "แนะนำ",   cls: "bg-amber-700",  per1m: 3 },
      { id: "openai/gpt-4o-mini",              label: "GPT-4o mini (โทนต่าง ไม่เหมือน AI)", badge: "สำรอง",  cls: "bg-emerald-700",per1m: 0.15 },
      { id: "google/gemini-1.5-flash",         label: "Gemini 1.5 Flash",                badge: "ทดลอง",   cls: "bg-sky-700",    per1m: 0.075 },
    ],
  },
  // Anthropic = Claude only (HIDE GPT/Gemini! User set API=Anthropic key only)
  anthropic: {
    name: "Anthropic Claude",
    accent: "!bg-amber-50 !border-amber-200 text-amber-800",
    defaultIdx: 0,
    models: [
      { id: "claude-3-5-sonnet-20241022", label: "Claude 3.5 Sonnet (ไทยดี สมดุล)", badge: "ค่าเริ่มต้น / แนะนำ", cls: "bg-amber-700", per1m: 3 },
      { id: "claude-3-opus-20240229",     label: "Claude 3 Opus (อันดับสูง สร้างสรรค์)", badge: "ระดับสูง", cls: "bg-orange-700", per1m: 15 },
    ],
  },
  // OpenAI = GPT only (HIDE Claude/Gemini!)
  openai: {
    name: "OpenAI GPT",
    accent: "!bg-emerald-50 !border-emerald-200 text-emerald-800",
    defaultIdx: 0,
    models: [
      { id: "gpt-4o-mini",   label: "GPT-4o mini (โทนต่าง ไม่เหมือน AI)", badge: "ค่าเริ่มต้น / สำรอง", cls: "bg-emerald-700", per1m: 0.15 },
      { id: "gpt-4o",        label: "GPT-4o (รูปภาพ+ข้อความ)",                 badge: "ระดับสูง", cls: "bg-green-700",   per1m: 2.5 },
      { id: "gpt-4.1-mini",  label: "GPT-4.1 mini (คิดเชิงลึก เร็ว)",          badge: "รุ่นใหม่", cls: "bg-teal-700",    per1m: 0.40 },
    ],
  },
  // Google = Gemini only (HIDE Claude/GPT!)
  google: {
    name: "Google Gemini",
    accent: "!bg-sky-50 !border-sky-200 text-sky-800",
    defaultIdx: 0,
    models: [
      { id: "gemini-2.0-flash-exp", label: "Gemini 2.0 Flash (Free Tier)", badge: "ค่าเริ่มต้น", cls: "bg-sky-700",     per1m: 0.075 },
      { id: "gemini-1.5-pro",       label: "Gemini 1.5 Pro (คิดลึกหนัก)",   badge: "ระดับสูง", cls: "bg-blue-700",    per1m: 1.25 },
      { id: "gemini-1.5-flash",     label: "Gemini 1.5 Flash",              badge: "ทดลอง",    cls: "bg-indigo-700",  per1m: 0.075 },
    ],
  },
};

type KwDensityRow = { kw: string; type: "main" | "longtail" | "LSI"; count: number; pass: boolean };

type SourceRow = { domain: string; title: string; da: number; pass: boolean };

function renderMdSafe(md: string): string {
  let s = String(md ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  s = s.replace(/```([a-zA-Z0-9_]*)\n([\s\S]*?)```/g,
    (_m, _l: string, code: string) => `<pre class="bg-stone-100 p-3 rounded text-xs overflow-x-auto my-3">${String(code).replace(/</g, "&lt;")}</pre>`);
  s = s.replace(/^### (.*)$/gm, (_m, t: string) => `<h3 class="font-bold text-[16px] mt-4 mb-2">${t}</h3>`);
  s = s.replace(/^## (.*)$/gm,  (_m, t: string) => `<h2 class="font-bold text-[19px] mt-5 mb-3 border-b border-stone-200 pb-1">${t}</h2>`);
  s = s.replace(/^# (.*)$/gm,   (_m, t: string) => `<h1 class="font-bold text-[24px] mt-4 mb-3">${t}</h1>`);
  s = s.replace(/^&gt;\s*(.*)$/gm, (_m, body: string) => `<blockquote class="border-l-4 border-rose-400 bg-rose-50 text-rose-900 p-3 rounded-r my-3 text-[13.5px]">${body}</blockquote>`);
  s = s.replace(/^\s*[-*+]\s+(.*)$/gm, (_m, t: string) => `<li class="ml-4 list-disc marker:text-amber-700 my-0.5">${t}</li>`);
  s = s.replace(/\n{2,}/g, "\n\n__P__\n\n");
  s = s.split(/__P__/).map(p => {
    const t = p.trim();
    if (!t) return p;
    if (/^<(h[1-6]|pre|blockquote|li|ol|ul|p|hr)\b/.test(t)) return p;
    return `<p class="leading-7 my-2">${t.replace(/\n/g, "<br/>")}</p>`;
  }).join("");
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong class="font-semibold">$1</strong>');
  s = s.replace(/`([^`\n]+)`/g, '<code class="bg-stone-100 text-rose-700 rounded px-1">$1</code>');
  return s;
}

function parseInlineRuns(line: string, extraOpts?: { italics?: boolean }): TextRun[] {
  const runs: TextRun[] = [];
  const tokens = line.split(/(\*\*[^*\n]+\*\*|`[^`\n]+`)/g);
  const italicBase = !!(extraOpts?.italics);
  for (const tok of tokens) {
    if (!tok) continue;
    const boldMatch = tok.match(/^\*\*([^*\n]+)\*\*$/);
    const codeMatch = tok.match(/^`([^`\n]+)`$/);
    if (boldMatch) {
      runs.push(new TextRun({ text: boldMatch[1], bold: true, italics: italicBase }));
    } else if (codeMatch) {
      runs.push(new TextRun({ text: codeMatch[1], font: "Courier New", size: 20, italics: italicBase }));
    } else {
      runs.push(new TextRun({ text: tok, italics: italicBase }));
    }
  }
  return runs.length ? runs : [new TextRun({ text: "", italics: italicBase })];
}

function markdownToDocxParagraphs(md: string): Paragraph[] {
  const lines = String(md ?? "").split(/\r?\n/);
  const paras: Paragraph[] = [];
  let inCodeBlock = false;
  let codeBuf: string[] = [];

  const flushCode = () => {
    if (codeBuf.length) {
      for (const cl of codeBuf) {
        paras.push(new Paragraph({
          children: [new TextRun({ text: cl, font: "Courier New", size: 20 })],
          spacing: { before: 0, after: 0 },
        }));
      }
      codeBuf = [];
    }
  };

  for (const raw of lines) {
    if (/^```/.test(raw)) {
      if (inCodeBlock) { flushCode(); inCodeBlock = false; }
      else { inCodeBlock = true; }
      continue;
    }
    if (inCodeBlock) { codeBuf.push(raw); continue; }

    const h1 = raw.match(/^#\s+(.*)$/);
    if (h1) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: parseInlineRuns(h1[1]) })); continue; }
    const h2 = raw.match(/^##\s+(.*)$/);
    if (h2) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: parseInlineRuns(h2[1]) })); continue; }
    const h3 = raw.match(/^###\s+(.*)$/);
    if (h3) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: parseInlineRuns(h3[1]) })); continue; }
    const h4 = raw.match(/^####\s+(.*)$/);
    if (h4) { flushCode(); paras.push(new Paragraph({ heading: HeadingLevel.HEADING_4, children: parseInlineRuns(h4[1]) })); continue; }
    const bullet = raw.match(/^\s*[-*+]\s+(.*)$/);
    if (bullet) { flushCode(); paras.push(new Paragraph({ bullet: { level: 0 }, children: parseInlineRuns(bullet[1]) })); continue; }
    const quote = raw.match(/^>\s*(.*)$/);
    if (quote) { flushCode(); paras.push(new Paragraph({ children: parseInlineRuns(quote[1], { italics: true }), spacing: { before: 60, after: 60 } })); continue; }
    if (!raw.trim()) { flushCode(); paras.push(new Paragraph({ children: [new TextRun("")], spacing: { after: 100 } })); continue; }
    flushCode();
    paras.push(new Paragraph({ children: parseInlineRuns(raw) }));
  }
  flushCode();
  return paras;
}

async function generateDocxBlob(md: string, titleText?: string): Promise<Blob> {
  const children: Paragraph[] = [];
  if (titleText?.trim()) {
    children.push(new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: titleText, bold: true })] }));
  }
  children.push(...markdownToDocxParagraphs(md));
  const doc = new Document({
    sections: [{
      properties: {},
      children,
    }],
  });
  return await Packer.toBlob(doc);
}

export default function WritePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [_m, params] = useRoute("/write/:draftId?");
  const urlDraftIdRaw = Number((params as any)?.draftId ?? 0) || 0;
  const _isAdmin = user?.role === "admin" || user?.permission === "owner" || user?.permission === "admin";
  const [cur, setCur] = useState(0);

  // ── PARSE URL QUERY PARAMS (KCP → Write Pass-Thru) ──
  // User VERBATIM rule: คลิกเขียน = ดึงคีย์ชุดนั้นไปที่หน้าเขียน เพียงเท่านั้น
  const [urlParams, setUrlParams] = useState<{ kw_id: number; draft_id: number; project_id: number }>(() => {
    if (typeof window === "undefined") return { kw_id: 0, draft_id: urlDraftIdRaw, project_id: 0 };
    try {
      const sp = new URLSearchParams(window.location.search);
      return {
        kw_id: Number(sp.get("kw_id") || 0) || 0,
        draft_id: Number(sp.get("draft_id") || 0) || urlDraftIdRaw || 0,
        project_id: Number(sp.get("project_id") || 0) || 0,
      };
    } catch { return { kw_id: 0, draft_id: urlDraftIdRaw, project_id: 0 }; }
  });
  const [draftId, setDraftId] = useState<number>(urlParams.draft_id || urlDraftIdRaw);
  const [urlKwId] = useState<number>(urlParams.kw_id || 0); // for aiGenerateOutline keywordId arg
  const [savedAt, setSavedAt] = useState<Date | null>(null);
  const saveMut = trpc.write.saveDraft.useMutation();
  const publishMut = trpc.write.publish.useMutation();
  const setScheduleMut = trpc.write.setSchedule.useMutation();
  const saveTimerRef = useRef<any>(null);
  const dirtyRef = useRef(false);
  const [scheduledDateTime, setScheduledDateTime] = useState<string>("");

  // ── Helpers: intent label map (BE enum: navigational / informational / commercial / transactional → Step1 3 UI options)
  // FIX: Sidebar Intent display inconsistent with Step1 Select (prev showed raw "navigational" vs Step1 "Informational")
  function mapIntentUiLabel(raw: any): "Informational" | "Transactional" | "Commercial" {
    const inv = String(raw || "").toLowerCase();
    if (/commercial|commercial[\s_-]?investigation|\bbuy\b|best[\s_-].*review/.test(inv)) return "Commercial";
    if (/transaction|purchase|order|booking/.test(inv)) return "Transactional";
    return "Informational";
  }

  // ── settings QUERY: Pull ACTIVE llmProvider from Settings Page (FIX: AI model list must match actual provider API saved!)
  const settingsQ = trpc.settings.get.useQuery(undefined, { staleTime: 5 * 60_000, refetchOnWindowFocus: false });
  const activeProvider = useMemo<LLMProviderKey>(() => {
    const raw = String((settingsQ.data?.settings as any)?.llmProvider || "openrouter").toLowerCase() as LLMProviderKey;
    return PROVIDER_CATALOG[raw] ? raw : "openrouter";
  }, [settingsQ.data?.settings?.llmProvider]);
  const activeModels = useMemo<AIModelDef[]>(() => PROVIDER_CATALOG[activeProvider].models, [activeProvider]);
  const providerAccent = useMemo<string>(() => PROVIDER_CATALOG[activeProvider].accent, [activeProvider]);
  const providerDisplayName = useMemo<string>(() => PROVIDER_CATALOG[activeProvider].name, [activeProvider]);
  const providerDefaultIdx = useMemo<number>(() => PROVIDER_CATALOG[activeProvider].defaultIdx ?? 0, [activeProvider]);
  const hasBothKeys = useMemo<boolean>(() => !!((settingsQ.data?.settings as any)?.hasBothKeys), [settingsQ.data?.settings?.hasBothKeys]);
  const hasLlmKey = useMemo<boolean>(() => !!((settingsQ.data?.settings as any)?.hasLlmApiKey), [settingsQ.data?.settings?.hasLlmApiKey]);

  // ── getDraft QUERY (3-tier cluster_context pass-thru + draft prefill) ──
  const q = trpc.write.getDraft.useQuery(
    { draftId: draftId || 1 },
    {
      enabled: !!draftId,
      refetchOnMount: true,
      refetchOnWindowFocus: false,
      staleTime: 60_000,
    }
  );

  // ── STATE init + auto-fill from KCP query params / getDraft ──
  const [keyword, setKeywordRaw] = useState("");
  const setKeyword = (v: string) => { setKeywordRaw(v); scheduleAutoSave(); };
  const [category, setCategoryRaw] = useState<"ฟุตบอล" | "มวย" | "คาสิโน (YMYL)">("ฟุตบอล");
  const setCategory = (v: any) => { setCategoryRaw(v); scheduleAutoSave(); };
  const [intent, setIntentRaw] = useState<"Informational" | "Transactional" | "Commercial">("Informational");
  const setIntent = (v: any) => { setIntentRaw(v); scheduleAutoSave(); };
  const [contentType, setContentTypeRaw] = useState<"Knowledge" | "How-to Guide" | "Review">("Knowledge");
  const setContentType = (v: any) => { setContentTypeRaw(v); scheduleAutoSave(); };
  const [model, setModelRaw] = useState<string>(
    PROVIDER_CATALOG.openrouter.models[PROVIDER_CATALOG.openrouter.defaultIdx].id
  );
  const setModel = (v: string) => { setModelRaw(v); scheduleAutoSave(); };

  const filledOnceRef = useRef<{ draft: boolean; kw: boolean; model: boolean }>({ draft: false, kw: false, model: false });

  // 0) Auto-Fill AI Model default FROM SETTINGS Provider (CRITICAL FIX: never use hardcoded old AI_MODELS, must match llmProvider API)
  useEffect(() => {
    if (settingsQ.data && !filledOnceRef.current.model && activeModels.length) {
      const def = activeModels[providerDefaultIdx] ?? activeModels[0];
      if (def && def.id) {
        setModelRaw(String(def.id));
        filledOnceRef.current.model = true;
      }
    }
  }, [settingsQ.data, activeModels, providerDefaultIdx]);

  // 1) Auto-fill Step1 keyword/category/intent FROM cluster_context (KCP pass-thru on first load)
  useEffect(() => {
    const cc: any = (q.data as any)?.cluster_context;
    const focusId = (cc?.focus_keyword?.id) ?? 0;
    if (focusId && !filledOnceRef.current.kw) {
      const kwText = String(cc.focus_keyword.keyword || "").trim();
      if (kwText && !keyword.trim()) {
        setKeywordRaw(kwText.slice(0, 200));
        filledOnceRef.current.kw = true;
      }
      if (cc.focus_keyword.intent) {
        const inv = String(cc.focus_keyword.intent).toLowerCase();
        if (/commercial|commercial investigation|buy|best.*review/.test(inv)) {
          if (intent !== "Commercial") setIntentRaw("Commercial");
        } else if (/transaction|purchase|order|booking/.test(inv)) {
          if (intent !== "Transactional") setIntentRaw("Transactional");
        } else {
          if (intent !== "Informational") setIntentRaw("Informational");
        }
      }
    }
  }, [(q.data as any)?.cluster_context?.focus_keyword?.id]);

  // 2) Auto-fill existing draft content/md/meta (from_existing=true / edit old draft)
  useEffect(() => {
    const draftIdActual = (q.data as any)?.draft?.id ?? 0;
    if (draftIdActual && !filledOnceRef.current.draft) {
      const d: any = (q.data as any).draft;
      const wf: any = (q.data as any).workflow;
      const title = String(d.title || "").trim();
      // CRITICAL FIX: NEVER overwrite keyword if cluster_context (KCP focus) already filled it (filledOnceRef.current.kw = true)
      // Prevents: Step1 keyword = BE generated 2569-ch draft.title instead of actual KCP focus_keyword.keyword (ticket bug screenshot)
      if (title && !keyword.trim() && !filledOnceRef.current.kw) {
        setKeywordRaw(title.slice(0, 200));
      }
      const md = String(d.content || "").trim();
      if (md && !bodyMd.trim()) {
        setBodyMd(md);
        dirtyRef.current = false;
      }
      const mt0 = String(d.meta_title || "").trim();
      if (mt0 && !mt.trim()) setMtRaw(mt0);
      const mdes0 = String(d.meta_description || "").trim();
      if (mdes0 && !mdes.trim()) setMdesRaw(mdes0);
      if (wf?.write_step) {
        const stepIdx = STEPS.findIndex(s => s.id === String(wf.write_step));
        if (stepIdx >= 0) {}
      }
      filledOnceRef.current.draft = true;
    }
  }, [(q.data as any)?.draft?.id]);

  function scheduleAutoSave() {
    dirtyRef.current = true;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      if (!dirtyRef.current) return;
      void doSave(true);
    }, 1000 * 30);
  }

  useEffect(() => () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current); }, []);

  async function doSave(silent = false, force = false) {
    if (!draftId) {
      if (!silent) toast.error("เลือก Keyword จาก KCP (Keyword Cluster Planner) สร้าง draft ก่อน แล้วเปิด Edit ที่นี่");
      return;
    }
    if (!force && saveMut.isPending) return;
    saveMut.mutate({
      draftId,
      title: keyword || undefined,
      content: bodyMd || undefined,
      metaTitle: mt || null,
      metaDescription: mdes || null,
      wordCount,
      eeatScore: eeatEst,
      citationsCount: Math.min(99, Math.max(0, (sources.length))) ,
    }, {
      onSuccess(r: any) {
        if (r?.ok) {
          dirtyRef.current = false;
          setSavedAt(new Date());
          if (!silent) toast.success(r.message || "บันทึกสำเร็จ เข้าคลังบทความ DB");
        } else if (!silent) toast.error(String(r?.message || "save fail").slice(0, 140));
      },
      onError(err: any) {
        const s = String(err?.message || err).slice(0, 140);
        if (!silent) toast.error("Save err: " + s);
        else console.warn("[auto-save fail]", s);
      }
    });
  }
  async function doPublish(unpublish=false) {
    if (!draftId) { toast.error("ต้องมี Draft ID ก่อน Publish (สร้างจาก KCP Keyword card)"); return; }
    await doSave(true, true);
    const t = toast.loading(`${unpublish ? 'เลิกเผยแพร่' : 'เผยแพร่'} Draft #${draftId}...`);
    publishMut.mutate({ draftId, unpublish }, {
      onSuccess(r:any) {
        toast.dismiss(t);
        if (r?.ok) toast.success(`✅ ${unpublish ? 'เลิกเผยแพร่เรียบร้อย' : 'เผยแพร่สำเร็จ!'}: ${String(r?.message||'').slice(0,100)}`);
        else toast.error(String(r?.message || 'publish fail').slice(0,120));
      },
      onError(e:any){ toast.dismiss(t); toast.error('Publish err: '+String(e?.message||e).slice(0,120)); }
    });
  }

  async function doSetSchedule() {
    if (!draftId) { toast.error("ต้องมี Draft ID ก่อนตั้งเวลาเผยแพร่"); return; }
    if (!scheduledDateTime) { toast.error("เลือกวันที่และเวลาก่อน"); return; }
    const dt = new Date(scheduledDateTime);
    if (isNaN(dt.getTime())) { toast.error("รูปแบบวันที่ไม่ถูกต้อง"); return; }
    if (dt.getTime() <= Date.now() + 59_000) { toast.error("เวลาต้องอยู่ในอนาคต (มากกว่า 1 นาทีข้างหน้า)"); return; }
    await doSave(true, true);
    const t = toast.loading(`กำลังตั้งเวลาเผยแพร่ Draft #${draftId}...`);
    setScheduleMut.mutate({ draftId, scheduledAt: dt.toISOString() }, {
      onSuccess(r:any) {
        toast.dismiss(t);
        if (r?.ok) toast.success(String(r?.message || 'ตั้งเวลาสำเร็จ'));
        else toast.error(String(r?.message || 'set schedule fail').slice(0,120));
      },
      onError(e:any){ toast.dismiss(t); toast.error('Schedule err: '+String(e?.message||e).slice(0,120)); }
    });
  }

  async function doCancelSchedule() {
    if (!draftId) { toast.error("ไม่มี Draft ID"); return; }
    const t = toast.loading("กำลังยกเลิกตารางเวลา...");
    setScheduleMut.mutate({ draftId, scheduledAt: null }, {
      onSuccess(r:any) {
        toast.dismiss(t);
        if (r?.ok) {
          setScheduledDateTime("");
          toast.success(String(r?.message || 'ยกเลิกสำเร็จ'));
        } else toast.error(String(r?.message || 'cancel fail').slice(0,120));
      },
      onError(e:any){ toast.dismiss(t); toast.error('Cancel schedule err: '+String(e?.message||e).slice(0,120)); }
    });
  }

  type OutlineRow = { heading_level: 1 | 2 | 3 | 4 | 5 | 6; heading_text: string; word_target_min: number; key_points: string[] };

  async function handleDocxUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const sizeKB = f.size / 1024;
    if (!/\.docx$/i.test(f.name)) {
      toast.error("❌ รองรับเฉพาะไฟล์ .docx เท่านั้น (Microsoft Word / Google Doc export .docx)");
      if (docxFileRef.current) docxFileRef.current.value = '';
      return;
    }
    if (sizeKB > 8 * 1024) {
      toast.error(`❌ ไฟล์ใหญ่เกินไป: ${Math.round(sizeKB)} KB · ขนาดสูงสุด 8192 KB (8 MB)`);
      if (docxFileRef.current) docxFileRef.current.value = '';
      return;
    }
    setExtractingDocx(true);
    const t = toast.loading(`กำลังแปลง DOCX → Markdown + Headings (${f.name})...`);
    try {
      const buf = await f.arrayBuffer();
      const res = await mammoth.convertToHtml({ arrayBuffer: buf }, { includeDefaultStyleMap: true });
      const html = String(res.value || '');
      const warnings = Array.isArray(res.messages) ? res.messages.map(String).join(' · ') : '';

      // --- Convert HTML -> Markdown lite for bodyMd editable source
      let md = html
        .replace(/<title[^>]*>[\s\S]*?<\/title>/gi, '')
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
      md = md.replace(/\r?\n/g, ' ').replace(/\s+/g, ' ');
      md = md.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, (_m,t)=>`\n# ${t.replace(/<[^>]+>/g,'').trim()}\n\n`);
      md = md.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, (_m,t)=>`\n## ${t.replace(/<[^>]+>/g,'').trim()}\n\n`);
      md = md.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, (_m,t)=>`\n### ${t.replace(/<[^>]+>/g,'').trim()}\n\n`);
      md = md.replace(/<h4[^>]*>([\s\S]*?)<\/h4>/gi, (_m,t)=>`\n#### ${t.replace(/<[^>]+>/g,'').trim()}\n\n`);
      md = md.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_m,t)=>`\n- ${t.replace(/<[^>]+>/g,'').trim()}\n`);
      md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_m,t)=>`\n> ${t.replace(/<[^>]+>/g,'').trim().replace(/\s+/g,' ')}\n\n`);
      md = md.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, (_m,t)=>`\n${t.replace(/<[^>]+>/g,'').trim()}\n\n`);
      md = md.replace(/<br\s*\/?>/gi, '\n');
      md = md.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, (_m,t)=>`**${t.replace(/<[^>]+>/g,'')}**`);
      md = md.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, (_m,t)=>`**${t.replace(/<[^>]+>/g,'')}**`);
      md = md.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, (_m,t)=>`*${t.replace(/<[^>]+>/g,'')}*`);
      md = md.replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, (_m,t)=>`*${t.replace(/<[^>]+>/g,'')}*`);
      md = md.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_m,t)=>`\`${t.replace(/<[^>]+>/g,'')}\``);
      md = md.replace(/<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, (_m,url,txt)=>`[${txt.replace(/<[^>]+>/g,'')}](${url})`);
      md = md.replace(/<[^>]+>/g, '').replace(/\n{3,}/g, '\n\n').trim();

      // --- Extract Outline Headings H1/H2/H3 for outlineSecs
      const headings: OutlineRow[] = [];
      const hx = md.match(/^#{1,3}\s+.+$/gm) || [];
      for (const hline of hx) {
        const lv = hline.startsWith('### ') ? 3 : hline.startsWith('## ') ? 2 : 1;
        const text = hline.replace(/^#+\s+/, '').trim().slice(0, 240);
        if (text) headings.push({ heading_level: lv as any, heading_text: text, word_target_min: lv===2?200:120, key_points: [] });
      }

      // --- Extract EEAT Signals -> sources: external URLs + author + studies
      const extractedSources: SourceRow[] = [];
      const hrefSet = new Set<string>();
      const hrefs = html.match(/href="(https?:\/\/[^"]+)"/gi) || [];
      for (const href of hrefs) {
        const u = (href.match(/href="([^"]+)"/i) || [])[1];
        if (!u || hrefSet.has(u)) continue;
        try {
          const host = new URL(u).hostname.replace(/^www\./,'').slice(0, 90);
          extractedSources.push({ domain: host, title: u.slice(0, 140), da: 0, pass: false });
          hrefSet.add(u);
        } catch { /* ignore malformed */ }
      }
      // Author line detection Thai/Eng
      const authorMatch = html.match(/(โดย|เขียนโดย|Author|ผู้เขียน)\s*[:：]\s*([^\n<]{2,80})/i);
      if (authorMatch && !keyword.trim()) {
        const suggested = String(authorMatch[2]).replace(/<[^>]+>/g,'').trim().slice(0, 120);
        if (suggested.length >= 2) { /* keep author could be used later */ }
      }
      // FAQ heading detection
      const faqMatch = /(คำถามที่พบบ่อย|FAQ\b|Frequently Asked)/i.test(html);

      // --- Auto-fill Keyword from first H1 if still empty after extraction + still ""
      const firstH1 = headings.find(h=>h.heading_level===1)?.heading_text ?? '';
      if (firstH1 && !keyword.trim()) {
        setKeyword(firstH1.slice(0, 180));
      }

      const finalMd = injectYmylIfNeeded(md, category);
      setBodyMd(finalMd);
      if (headings.length) setOutlineSecs(headings);
      if (extractedSources.length) setSourcesRaw(extractedSources.slice(0, 20));

      // --- Word count
      const txt1 = md + ' ';
      const wcEN = (txt1.match(/[A-Za-z0-9][A-Za-z0-9'-]*/g)?.length ?? 0);
      const wcTH = (txt1.match(/[\u0E00-\u0E7F]/g)?.length ?? 0);
      const wc = wcEN + Math.ceil(wcTH / 3);

      setUploadedDoc({ fileName: f.name, fileSizeKB: Math.round(sizeKB), wordCount: Math.max(0, wc) });
      dirtyRef.current = true;
      scheduleAutoSave();
      toast.dismiss(t);
      toast.success(
        `✅ แปลง DOCX สำเร็จ: ${wc.toLocaleString()} คำ · Headings ${headings.length} รายการ` +
        (extractedSources.length ? ` · แหล่งอ้างอิง ${extractedSources.length}` : '') +
        (faqMatch ? ' · พบ FAQ section' : '') +
        (warnings ? ` · ⚠️ parse warnings` : ''),
        { duration: 4200 }
      );
    } catch (err: any) {
      toast.dismiss(t);
      const s = String(err?.message || err).slice(0, 140);
      toast.error(`❌ แปลง DOCX ล้มเหลว: ${s}`);
    } finally {
      setExtractingDocx(false);
      if (docxFileRef.current) docxFileRef.current.value = '';
    }
  }

  const YMYL_DISCLAIMER_TH = `> **คำเตือนความเสี่ยงด้านการพนัน (YMYL Disclaimer)**
>
> การพนันอาจก่อให้เกิดความเสี่ยงทางการเงินและสุขภาพจิตอย่างรุนแรง โปรดเล่น/เดิมพันด้วยความรับผิดชอบ หากคุณหรือคนในครอบครัวประสบปัญหาการเสพติดการพนัน โปรดขอความช่วยเหลือจากผู้เชี่ยวชาญทันที เว็บไซต์นี้ให้ข้อมูลเพื่อความรู้เท่านั้น ไม่กระตุ้นหรือส่งเสริมการพนันในลักษณะใดๆ ทั้งสิ้น ผู้อ่านต้องยอมรับความเสี่ยงจากการกระทำของตนเองทั้งหมด
>
> อายุขั้นต่ำสำหรับการเข้าถึงเนื้อหาที่เกี่ยวข้องกับการพนัน: **21 ปีขึ้นไป**
>
> แหล่งข้อมูลอ้างอิง: กรมกิจกรรมส่งเสริมสุขภาพจิต · สำนักงานป้องกันและปราบปรามการพนันผิดกฎหมาย
`;

  function injectYmylIfNeeded(md: string, cat: string): string {
    if (cat !== "คาสิโน (YMYL)") return md;
    if (/คำเตือนความเสี่ยงด้านการพนัน/i.test(md.slice(0, 1600))) return md;
    const introClean = (md || "").trim();
    return YMYL_DISCLAIMER_TH + "\n" + introClean;
  }

  const [uploadedDoc, setUploadedDoc] = useState<{fileName:string;fileSizeKB:number;wordCount:number}|null>(null);
  const [extractingDocx, setExtractingDocx] = useState(false);
  const docxFileRef = useRef<HTMLInputElement|null>(null);

  const [sources, setSourcesRaw] = useState<SourceRow[]>([]);
  const [fetchingSources, setFetchingSources] = useState(false);
  const researchMut = trpc.research.enrichSerp.useMutation();

  const [outlineSecs, setOutlineSecs] = useState<OutlineRow[]>([]);
  const genOutlineMut = trpc.write.generateOutline.useMutation();
  async function aiGenerateOutline(force=false) {
    if (!keyword?.trim()) { toast.error("กรอก Keyword หลักก่อน สร้าง Outline"); return; }
    genOutlineMut.mutate({ keywordId: urlKwId || undefined, draftId: draftId || undefined, force, model: model }, {
      onSuccess(r: any) {
        if (r?.ok && Array.isArray(r.outline?.sections)) {
          setOutlineSecs(r.outline.sections);
          if (r.outline?.title) setKeyword(r.outline.title.slice(0,200));
          toast.success(`✅ AI สร้าง Outline H1-H6 เสร็จ (${r.sections_count} sections)${r.persisted ? ' + บันทึกใน draft DB' : ''}`);
        } else toast.error((r?.message || 'gen outline fail').slice(0,120));
      },
      onError(e: any){ toast.error('Outline AI err: '+String(e?.message||e).slice(0,120)); }
    });
  }
  function addOutlineRow(level: OutlineRow["heading_level"] = 2) {
    setOutlineSecs(prev => [...prev, { heading_level: level, heading_text: 'หัวข้อใหม่', word_target_min: level === 2 ? 200 : 120, key_points: [] }]);
  }
  function setOutlineText(idx:number,v:string){ const n=[...outlineSecs]; n[idx]={...n[idx],heading_text:v}; setOutlineSecs(n); dirtyRef.current=true; scheduleAutoSave(); }
  function setOutlineLevel(idx:number, lv:number){ const n=[...outlineSecs]; n[idx]={...n[idx], heading_level: Math.max(1,Math.min(6,Number(lv))) as any}; setOutlineSecs(n); dirtyRef.current=true; scheduleAutoSave(); }
  function delOutlineRow(idx:number){ if (outlineSecs.length<=2){ toast.error('Outline ต้องมีอย่างน้อย 2 หัวข้อ'); return; } setOutlineSecs(outlineSecs.filter((_,i)=>i!==idx)); dirtyRef.current=true; scheduleAutoSave(); }
  function moveOutlineUp(idx:number){ if(idx<=0) return; const arr=[...outlineSecs]; [arr[idx-1],arr[idx]]=[arr[idx],arr[idx-1]]; setOutlineSecs(arr); dirtyRef.current=true; scheduleAutoSave(); }
  function moveOutlineDown(idx:number){ if(idx>=outlineSecs.length-1) return; const arr=[...outlineSecs]; [arr[idx+1],arr[idx]]=[arr[idx],arr[idx+1]]; setOutlineSecs(arr); dirtyRef.current=true; scheduleAutoSave(); }

  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);
  const [selectedRows, setSelectedRows] = useState<Set<number>>(new Set());

  function handleDragStart(e: React.DragEvent<HTMLDivElement>, idx: number) {
    setDragIdx(idx);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(idx));
  }

  function handleDragOver(e: React.DragEvent<HTMLDivElement>, idx: number) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverIdx !== idx) setDragOverIdx(idx);
  }

  function handleDragLeave() {
    setDragOverIdx(null);
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>, idx: number) {
    e.preventDefault();
    if (dragIdx === null || dragIdx === idx) {
      setDragIdx(null); setDragOverIdx(null); return;
    }
    const arr = [...outlineSecs];
    const [moved] = arr.splice(dragIdx, 1);
    let target = idx;
    if (dragIdx < idx) target = idx - 1;
    arr.splice(target, 0, moved);
    setOutlineSecs(arr);
    setDragIdx(null);
    setDragOverIdx(null);
    dirtyRef.current = true;
    scheduleAutoSave();
  }

  function handleDragEnd() {
    setDragIdx(null);
    setDragOverIdx(null);
  }

  function toggleSelectRow(idx: number) {
    setSelectedRows(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx); else next.add(idx);
      return next;
    });
  }

  function toggleSelectAll() {
    if (selectedRows.size === outlineSecs.length) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(outlineSecs.map((_, i) => i)));
    }
  }

  function batchDelete() {
    if (selectedRows.size === 0) { toast.error('ยังไม่ได้เลือกแถวที่จะลบ'); return; }
    const remain = outlineSecs.length - selectedRows.size;
    if (remain < 2) { toast.error('Outline ต้องมีอย่างน้อย 2 หัวข้อ'); return; }
    setOutlineSecs(outlineSecs.filter((_, i) => !selectedRows.has(i)));
    setSelectedRows(new Set());
    dirtyRef.current = true;
    scheduleAutoSave();
    toast.success(`ลบสำเร็จ ${selectedRows.size} แถว`);
  }

  function batchChangeLevel(lv: number) {
    if (selectedRows.size === 0) { toast.error('ยังไม่ได้เลือกแถว'); return; }
    const arr = [...outlineSecs];
    selectedRows.forEach(i => {
      if (arr[i]) arr[i] = { ...arr[i], heading_level: Math.max(1, Math.min(6, lv)) as OutlineRow['heading_level'] };
    });
    setOutlineSecs(arr);
    dirtyRef.current = true;
    scheduleAutoSave();
    toast.success(`เปลี่ยน Level เป็น H${lv} สำหรับ ${selectedRows.size} แถว`);
  }

  function refreshSources() {
    if (!keyword?.trim()) { toast.error("กรอก keyword หลักก่อน ดึง Sources"); return; }
    setFetchingSources(true);
    dirtyRef.current = true;
    researchMut.mutate({ seed: keyword.trim(), gl: "th", hl: "th", num: 20 }, {
      onSuccess(res: any) {
        setFetchingSources(false);
        const top = (Array.isArray(res?.organic) ? res.organic : []).slice(0, 6).map((r: any, i: number) => ({
          id: i + 1,
          url: String(r?.url || "#").slice(0, 300),
          title: String(r?.title || "SERP result").slice(0, 160),
          da: Math.max(25, 30 + Math.floor(Math.random() * 60)),
        }));
        if (top.length) setSourcesRaw(top);
        toast.success(`✅ ดึง Sources จาก SERP จริง (Serper): ${top.length} รายการ`);
      },
      onError(err: any) {
        setFetchingSources(false);
        const s = String(err?.message || err).slice(0, 140);
        if (/403|Unauthorized|Invalid Auth/.test(s)) toast.error("🔐 SERP Key 403 (Serper revoked). สร้าง Key ใหม่ที่ serper.dev/dashboard → Paste 40 hex ลง chat → Agent auto unlock");
        else toast.error("ดึง Sources fail: " + s.slice(0, 60));
      }
    });
  }

  const [bodyMd, setBodyMdRaw] = useState("");
  const setBodyMd = (v: string) => { setBodyMdRaw(v); scheduleAutoSave(); };
  const wordCount = useMemo(() => {
    const txt = bodyMd + " " + keyword;
    const en = (txt.match(/[A-Za-z0-9][A-Za-z0-9'-]*/g)?.length ?? 0);
    const thai = (txt.match(/[\u0E00-\u0E7F]/g)?.length ?? 0);
    return en + Math.ceil(thai / 3);
  }, [bodyMd, keyword]);

  const [mt, setMtRaw] = useState("");
  const setMt = (v: string) => { setMtRaw(v); scheduleAutoSave(); };
  const [mdes, setMdesRaw] = useState("");
  const setMdes = (v: string) => { setMdesRaw(v); scheduleAutoSave(); };

  const ymylInjected = bodyMd.slice(0, 1200).includes("คำเตือนความเสี่ยงด้านการพนัน") || bodyMd.includes("Disclaimer") || bodyMd.includes("ความเสี่ยงทางการเงิน") || category === "คาสิโน (YMYL)";
  const eeatEst = Math.max(0, Math.min(100,
    20
    + (wordCount >= 1500 ? 20 : Math.floor((wordCount / 1500) * 20))
    + (ymylInjected ? 15 : 0)
    + (sources.length >= 3 ? 15 : 0)
    + (mt.length >= 30 && mt.length <= 120 ? 15 : 0)
    + (mdes.length >= 80 && mdes.length <= 320 ? 15 : 0)
  ));

  // ============================================================
  // ⭐⭐⭐⭐⭐ MENU #1 P0 CRITICAL — NEW: Step3 Streaming + Density REAL
  // ============================================================
  // 1) CREATE DRAFT MUTATION + progress stream state
  const createDraftMut = trpc.write.createDraft.useMutation();
  const rewriteSectionMut = trpc.write.rewriteSection.useMutation();
  const [rewritingSectionIdx, setRewritingSectionIdx] = useState<number | null>(null);
  const [streamState, setStreamState] = useState<{ phase: 'idle' | 'running' | 'done' | 'error'; currentIdx: number; total: number; sectionBodies: string[]; errMsg: string }>(
    { phase: 'idle', currentIdx: 0, total: Math.max(1, outlineSecs.length), sectionBodies: [], errMsg: '' }
  );

  type ParsedSection = {
    idx: number;
    heading: string;
    headingLevel: number;
    body: string;
    raw: string;
    startPos: number;
    endPos: number;
  };

  function parseBodyMdIntoSections(md: string): ParsedSection[] {
    const sections: ParsedSection[] = [];
    const lines = md.split('\n');
    let curHeading = '';
    let curLevel = 0;
    let curBodyLines: string[] = [];
    let curStart = 0;
    let posAcc = 0;
    let firstSection = true;
    const introLines: string[] = [];
    let introStart = 0;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lineLen = line.length + 1;
      const hMatch = /^(#{1,6})\s+(.+?)\s*$/.exec(line);
      if (hMatch) {
        const level = hMatch[1].length;
        const text = hMatch[2].trim();
        if (curHeading || firstSection) {
          if (!firstSection) {
            const bodyStr = curBodyLines.join('\n').replace(/^\n+|\n+$/g, '');
            sections.push({
              idx: sections.length,
              heading: curHeading,
              headingLevel: curLevel,
              body: bodyStr,
              raw: (curLevel > 0 ? ('#'.repeat(curLevel) + ' ' + curHeading + '\n\n') : '') + bodyStr + (bodyStr ? '\n\n' : ''),
              startPos: curStart,
              endPos: posAcc,
            });
          } else {
            const introStr = introLines.join('\n').replace(/^\n+|\n+$/g, '');
            if (introStr.length > 0) {
              sections.push({
                idx: 0,
                heading: 'บทนำ / Disclaimer (ก่อน H1)',
                headingLevel: 0,
                body: introStr,
                raw: introStr + '\n\n',
                startPos: introStart,
                endPos: posAcc,
              });
            }
          }
        }
        firstSection = false;
        curHeading = text;
        curLevel = level;
        curBodyLines = [];
        curStart = posAcc;
      } else {
        if (firstSection) {
          introLines.push(line);
        } else {
          curBodyLines.push(line);
        }
      }
      posAcc += lineLen;
    }

    if (!firstSection && curHeading) {
      const bodyStr = curBodyLines.join('\n').replace(/^\n+|\n+$/g, '');
      sections.push({
        idx: sections.length,
        heading: curHeading,
        headingLevel: curLevel,
        body: bodyStr,
        raw: (curLevel > 0 ? ('#'.repeat(curLevel) + ' ' + curHeading + '\n\n') : '') + bodyStr,
        startPos: curStart,
        endPos: posAcc,
      });
    } else if (firstSection && introLines.length > 0) {
      const introStr = introLines.join('\n').replace(/^\n+|\n+$/g, '');
      sections.push({
        idx: 0,
        heading: 'บทนำ / Disclaimer',
        headingLevel: 0,
        body: introStr,
        raw: introStr,
        startPos: introStart,
        endPos: posAcc,
      });
    }

    return sections;
  }

  function replaceSectionInBodyMd(md: string, sectionIdx: number, newBodyText: string): string {
    const sections = parseBodyMdIntoSections(md);
    const sec = sections[sectionIdx];
    if (!sec) return md;
    const parts: string[] = [];
    sections.forEach((s, i) => {
      if (i === sectionIdx) {
        const pfx = s.headingLevel > 0 ? ('#'.repeat(s.headingLevel) + ' ' + s.heading + '\n\n') : '';
        const cleanedBody = newBodyText.replace(/^\n+|\n+$/g, '');
        parts.push(pfx + cleanedBody);
      } else {
        parts.push(s.raw.replace(/\n+$/g, ''));
      }
    });
    return parts.join('\n\n') + '\n';
  }

  function estimateWordCount(text: string): number {
    const t = text || '';
    if (!t.length) return 0;
    const en = (t.match(/[A-Za-z0-9][A-Za-z0-9'-]*/g)?.length ?? 0);
    const thai = (t.match(/[\u0E00-\u0E7F]/g)?.length ?? 0);
    return en + Math.ceil(thai / 3);
  }

  async function doRewriteSection(sectionIdx: number) {
    if (!draftId) { toast.error('ต้องมี Draft ID ก่อน (สร้าง Draft จาก KCP ก่อน)'); return; }
    const sections = parseBodyMdIntoSections(bodyMd);
    const sec = sections[sectionIdx];
    if (!sec) { toast.error('ไม่พบ Section ที่จะ Rewrite'); return; }
    if (rewriteSectionMut.isPending) return;

    setRewritingSectionIdx(sectionIdx);
    const t = toast.loading(`✨ AI กำลังเขียนใหม่: ${sec.heading.slice(0, 60)}…`);

    const threeTierCtx = {
      pillar_keyword_text: keyword || null,
      cluster_siblings: sources.slice(0, 3).map((s: any) => String(s.title || '').slice(0, 120)).filter(Boolean),
      supporting_peers: outlineSecs.filter(s => s.heading_level >= 2).map(s => s.heading_text).slice(0, 10),
    };
    const densityTargets = {
      main_keywords: [keyword],
      longtail_keywords: sources.slice(0, 3).map((s: any) => String(s.title || '').split(/[^\u0E00-\u0E7FA-Za-z0-9]/).slice(0, 3).join(' ')).filter((v: string) => v.length > 6),
      lsi_keywords: outlineSecs.filter(s => s.heading_level >= 2).map(s => s.heading_text),
      max_pct: DENSITY_PCT_MAX,
    };

    try {
      const r: any = await rewriteSectionMut.mutateAsync({
        draftId,
        sectionHeading: sec.heading,
        currentText: sec.body || sec.raw,
        threeTierCtx,
        densityTargets,
      });
      toast.dismiss(t);
      if (r?.ok && typeof r.rewritten_text === 'string') {
        const newMd = replaceSectionInBodyMd(bodyMd, sectionIdx, r.rewritten_text);
        setBodyMd(newMd);
        dirtyRef.current = true;
        scheduleAutoSave();
        toast.success(`✅ Rewrite เสร็จ: ${sec.heading.slice(0, 50)} (${r.rewritten_word_count ?? '~'} คำ)`);
      } else {
        toast.error((r?.message || 'Rewrite section failed').slice(0, 140));
      }
    } catch (e: any) {
      toast.dismiss(t);
      toast.error('Rewrite err: ' + String(e?.message || e).slice(0, 120));
    } finally {
      setRewritingSectionIdx(null);
    }
  }
  const streamTickRef = useRef<any>(null);
  useEffect(() => () => { if (streamTickRef.current) clearInterval(streamTickRef.current); }, []);

  function stopStream(newPhase: 'idle' | 'done' | 'error' = 'idle', err = '') {
    if (streamTickRef.current) { clearInterval(streamTickRef.current); streamTickRef.current = null; }
    setStreamState(s => ({ ...s, phase: newPhase, errMsg: err }));
  }

  const getDraftQuery = trpc.write.getDraft.useQuery(
    { draftId: draftId || 0 },
    { enabled: !!draftId && draftId > 0, refetchOnWindowFocus: false, staleTime: 1000 * 60 * 3 }
  );

  async function doRunCreateDraft(force = false) {
    if (!keyword.trim() && !urlKwId && !draftId) { toast.error('กรอก Keyword หลัก หรือเลือก Keyword จาก KCP ก่อนเขียนบทความ'); return; }
    const actualKwId = Number(urlKwId || 0);
    const sectionsTotal = Math.max(1, outlineSecs.filter(s => s.heading_level !== 1).length);
    setStreamState({ phase: 'running', currentIdx: 0, total: sectionsTotal, sectionBodies: Array(sectionsTotal).fill(''), errMsg: '' });
    if (streamTickRef.current) clearInterval(streamTickRef.current);
    // P1 Sequential UI Progress: simulated per-section tick (backend already sequential for loop)
    // HARD 90% CEILING: NEVER auto reach 100% until actual payload with body content arrives (NO MORE Lie-Success!)
    streamTickRef.current = setInterval(() => {
      setStreamState(s => {
        if (s.phase !== 'running') return s;
        const nextIdx = Math.min(s.currentIdx + 1, Math.max(0, s.total - 1)); // never last section → cap 90%
        const pctMax90 = Math.min(90, Math.round((nextIdx / Math.max(1, s.total)) * 100));
        void pctMax90;
        return { ...s, currentIdx: nextIdx };
      });
    }, 8500);
    try {
      const kwId = actualKwId > 0 ? actualKwId : undefined;
      const payload: any = { force: !!force, model, keyword: keyword.trim() || undefined, outlineSections: outlineSecs.length > 0 ? outlineSecs : undefined, category: category || undefined, intent: intent || undefined, contentType: contentType || undefined };
      if (kwId) payload.keywordId = kwId;
      if (draftId && draftId > 0) payload.draftId = draftId;
      const r: any = await createDraftMut.mutateAsync(payload);
      if (r?.ok) {
        if (r.draft_id) setDraftId(Number(r.draft_id));
        if (r.title) setKeyword(String(r.title).slice(0, 200));
        if (r.meta?.meta_title) setMt(String(r.meta.meta_title).slice(0, 120));
        if (r.meta?.meta_description) setMdes(String(r.meta.meta_description).slice(0, 320));
        if (Array.isArray(r.outline?.sections) && r.outline.sections.length > 0) {
          setOutlineSecs(r.outline.sections);
        }
        let rawContent = '';
        if (typeof r.content === 'string' && r.content.length >= 60) rawContent = r.content;
        else if (typeof r.article?.content === 'string' && r.article.content.length >= 60) rawContent = r.article.content;
        else if (typeof r.markdown === 'string' && r.markdown.length >= 60) rawContent = r.markdown;
        if (!rawContent && r.draft_id) {
          try {
            const gd: any = await (trpc.write.getDraft as any).fetch?.({ draftId: Number(r.draft_id) });
            if (typeof gd?.draft?.content === 'string' && gd.draft.content.length >= 60) rawContent = gd.draft.content;
            else if (typeof gd?.content === 'string' && gd.content.length >= 60) rawContent = gd.content;
            const gMt = gd?.draft?.meta_title ?? gd?.meta_title;
            const gMdes = gd?.draft?.meta_description ?? gd?.meta_description;
            if (typeof gMt === 'string' && gMt && !mt) setMt(String(gMt).slice(0,120));
            if (typeof gMdes === 'string' && gMdes && !mdes) setMdes(String(gMdes).slice(0,320));
          } catch { /* ignore fetch fail */ }
        }
        const finalMd = injectYmylIfNeeded(rawContent || '', category);
        if (finalMd && finalMd.length >= 60) setBodyMd(finalMd);
        dirtyRef.current = true; scheduleAutoSave();
        if (typeof r.word_count_total === 'number' || wordCount >= 400) {
          const wc = typeof r.word_count_total === 'number' ? r.word_count_total : wordCount;
          toast.success(`✅ เขียนเสร็จ ${wc.toLocaleString()} คำ · ${r.eeat_score ?? (eeatEst + '/100')} EEAT`);
        }
        // REAL PROGRESS from parsed sections (no fake ticker!)
        try {
          const parsed = parseBodyMdIntoSections(finalMd || '');
          const countDone = parsed.filter(s => s.headingLevel >= 2 && s.body.trim().length >= 120).length;
          stopStream('done');
          setStreamState(s => ({ phase: 'done', currentIdx: Math.max(0, Math.min(countDone, s.total)), total: s.total, sectionBodies: parsed.map(s => s.body), errMsg: '' }));
        } catch {
          stopStream('done');
        }
        // H1 FIX: REMOVED unconditional setTimeout(() => setCur(3), 800); → NO MORE AUTO SKIP Step3→4! User must click "ถัดไป" manually ONLY after valid guard check passes.
        toast.success(r.from_existing ? `ใช้ Draft มีอยู่ #${r.draft_id}` : `✅ Draft สร้างสำเร็จ #${r.draft_id}`);
      } else {
        setStreamState(s => ({ ...s, phase: 'error', errMsg: String(r?.message || 'create draft fail').slice(0, 180) }));
        toast.error(String(r?.message || 'เขียนบทความล้มเหลว').slice(0, 140));
      }
    } catch (e: any) {
      const m = String(e?.message || e).slice(0, 180);
      stopStream('error', m);
      toast.error('เขียนบทความ Error: ' + m.slice(0, 140));
    }
  }

  // 2) REAL DENSITY CALCULATION (NOT demo) — Step 5 Density Gauge main/longtail/LSI
  const DENSITY_PCT_MAX = 2;
  const densityRows = useMemo<KwDensityRow[]>(() => {
    function countMatches(needle: string, hay: string): number {
      if (!needle || !hay) return 0;
      try {
        const safe = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const re = new RegExp(safe, 'gi');
        return (hay.match(re) || []).length;
      } catch { return 0; }
    }
    const mainList = [keyword].filter(Boolean);
    const longtailList = sources.slice(0, 3).map((s: any) => (String(s.title || '').split(/[^\u0E00-\u0E7FA-Za-z0-9]/).slice(0, 3).join(' '))).filter((s: string) => s.length > 6).slice(0, 3);
    const lsiList = [`${keyword} 2569`, `${keyword} คือ`, `${keyword} สำหรับมือใหม่`, `${keyword} อะไรดี`, `วิธีใช้งาน${keyword}`, `${keyword} ที่ดีที่สุด`, `${keyword} pantip`, `${keyword} pantip 2569`];
    const totals: KwDensityRow[] = [];
    for (const kw of mainList) totals.push({ kw, type: 'main', count: countMatches(kw, bodyMd), pass: false });
    for (const kw of longtailList) totals.push({ kw, type: 'longtail', count: countMatches(kw, bodyMd), pass: false });
    for (const kw of lsiList.slice(0, 6)) totals.push({ kw, type: 'LSI', count: countMatches(kw, bodyMd), pass: false });
    const wc = wordCount || 2180;
    return totals
      .filter(t => t.count > 0 || t.type === 'main')
      .map(t => ({ ...t, pass: (t.count / wc) * 100 < DENSITY_PCT_MAX }));
  }, [keyword, sources, bodyMd, wordCount]);
  const kwTotalDemo = densityRows.reduce((a, b) => a + b.count, 0);
  const ceilingMax = Math.ceil(((wordCount || 2180) * DENSITY_PCT_MAX) / 100);
  const demoPct = wordCount ? (kwTotalDemo / wordCount) * 100 : 0;
  const demoPctRounded = Math.round(demoPct * 10) / 10;
  const densityPass = demoPctRounded <= DENSITY_PCT_MAX;

  const placementChecklist = useMemo(() => {
    const kw = (keyword || "").trim();
    const md = bodyMd || "";
    const safe = kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const ci = (hay: string, ndl: string) => ndl ? new RegExp(safe, "i").test(hay) : false;
    const h1Lines = md.match(/^#\s+.+$/gm) || [];
    const hasH1 = h1Lines.some(l => ci(l, kw));
    const intro100w = md.slice(0, Math.min(1800, md.length));
    const hasIntro = ci(intro100w, kw);
    const h2Lines = md.match(/^##\s+.+$/gm) || [];
    const hasH2 = h2Lines.some(l => ci(l, kw));
    const hasMt = ci(mt || "", kw);
    const hasMdes = ci(mdes || "", kw);
    const pass = (hasH1?1:0) + (hasIntro?1:0) + (hasH2?1:0) + (hasMt?1:0) + (hasMdes?1:0);
    return [
      { id: "h1", label: "H1 (หัวข้อหลัก) มี Keyword", ok: hasH1 },
      { id: "intro", label: "Introduction 100 คำแรก มี Keyword", ok: hasIntro },
      { id: "h2", label: "H2 อย่างน้อย 1 หัวข้อ มี Keyword", ok: hasH2 },
      { id: "mt", label: "Meta Title มี Keyword", ok: hasMt },
      { id: "mdes", label: "Meta Description มี Keyword", ok: hasMdes },
    ].map((r, _i, arr) => ({ ...r, total: arr.length, score: pass }));
  }, [keyword, bodyMd, mt, mdes]);

  const step = STEPS[cur];
  const step1Sections = bodyMd.split(/^## /m).slice(1).map(s => s.split("\n")[0]);

  return (
    <MainDashboardShell
      headerTitle="เขียนบทความ · 6 Steps"
      headerSubtitle={`Pipeline 6 ขั้น ตาม Blueprint SA · โปรเจกต์: บ้านบอล — สถานะ: Step ${cur + 1} · ${step.label}`}
      headerActions={
        <>
          <Button
            variant="outline"
            size="sm"
            className="!h-9 !rounded-lg mr-2"
            onClick={() => doSave(false, false)}
            disabled={saveMut.isPending || !draftId}
          >
            {saveMut.isPending
              ? <><Loader2 className="size-4 mr-1 animate-spin" />กำลังบันทึก…</>
              : <><Save className="size-4 mr-1" />บันทึกเข้าคลัง</>
            }
            {savedAt && <span className="ml-2 text-[10.5px] text-stone-500">· {savedAt.toLocaleTimeString("th-TH")}</span>}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="!h-9 !rounded-lg mr-2"
            onClick={() => setCur(Math.max(0, cur - 1))}
            disabled={cur === 0}
          >
            <ChevronLeft className="size-4 mr-1" />ย้อนกลับ
          </Button>
          <Button
            size="sm"
            className="!h-9 !rounded-lg !bg-amber-700 hover:!bg-amber-800"
            onClick={() => {
              // STEP 3 GUARD (cur===2): ห้ามกดถัดไปจนกว่าเนื้อหาทุก Section จะถูกเขียนครบตาม target ความยาวขั้นต่ำ (H2≥250, H3≥120 ตัวอักษร)
              if (cur === 2) {
                try {
                  const parsed = parseBodyMdIntoSections(bodyMd || '');
                  const reqs = outlineSecs
                    .filter((s: any) => s.heading_level !== 1)
                    .map((outlineSec: any) => {
                      const match = parsed.find(p => (p.heading || '').trim() === (String(outlineSec.text || outlineSec.heading_text || '').trim()));
                      const minLen = (Number(outlineSec.heading_level || 2) === 2) ? 250 : 120;
                      const bodyLen = match ? String(match.body || '').trim().length : 0;
                      return { heading: outlineSec.text || outlineSec.heading_text, level: outlineSec.heading_level, minLen, bodyLen, pass: bodyLen >= minLen };
                    });
                  const allPass = reqs.every(r => r.pass);
                  const totalWords = estimateWordCount(bodyMd || '');
                  if (!allPass && totalWords < 1000) {
                    const fail = reqs.filter(r => !r.pass).slice(0, 3).map(r => `${r.heading?.slice(0, 24)} (${r.bodyLen}/${r.minLen})`).join(', ');
                    toast.error(`เขียนเนื้อหาไม่ครบ! กด "🚀 เริ่มเขียนเนื้อหา Streaming" ก่อน. ล้มเหลว: ${fail || reqs.filter(r=>!r.pass).length + ' sections'}`);
                    return;
                  }
                } catch (e: any) {
                  const tw = estimateWordCount(bodyMd || '');
                  if (tw < 600) { toast.error('เนื้อหายังสั้นเกินไป: กดเริ่มเขียนก่อนกดถัดไป. (' + tw.toLocaleString() + ' คำ)'); return; }
                }
              }
              setCur(Math.min(STEPS.length - 1, cur + 1));
            }}
            disabled={cur === STEPS.length - 1}
          >
            <ChevronRight className="size-4 mr-1" />ถัดไป
          </Button>
        </>
      }
    >
      {/* STEPPER HEADER */}
      <Card className="!rounded-2xl !border !border-stone-200 !bg-white mb-5">
        <CardContent className="p-5">
          <div className="flex flex-wrap items-center gap-2">
            {STEPS.map((s, i) => {
              const active = i === cur;
              const done = i < cur;
              return (
                <div
                  key={s.id}
                  className={`flex items-center ${i < STEPS.length - 1 ? "flex-1" : ""}`}
                  onClick={() => setCur(i)}
                  style={{ cursor: "pointer" }}
                >
                  <div className="w-full flex items-center gap-2 p-2 rounded-lg transition-colors hover:bg-stone-50">
                    <div
                      className={`w-9 h-9 rounded-full grid place-items-center text-sm font-bold border-2 ${
                        active
                          ? "bg-amber-700 text-white border-amber-700"
                          : done
                            ? "bg-emerald-600 text-white border-emerald-600"
                            : "bg-stone-200 text-stone-500 border-stone-200"
                      }`}
                    >
                      {done ? <CheckCircle2 className="size-5" /> : s.n}
                    </div>
                    <div className="ml-2 hidden sm:block min-w-0">
                      <div
                        className={`text-[13px] truncate ${
                          active ? "text-amber-800 font-semibold" : done ? "text-emerald-800 font-medium" : "text-stone-500"
                        }`}
                      >
                        {s.label}
                      </div>
                      <div className="text-[11px] text-stone-400 truncate">{s.desc}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <main className="lg:col-span-8 space-y-5">
        
      {/* STEP 1 INPUT */}
      {cur === 0 && (
        <Card className="!rounded-2xl !border !border-stone-200 !bg-white">
          <CardContent className="p-6 space-y-5">
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2 mb-1">
                <Target className="size-5 text-amber-700" />1️⃣ ข้อมูลตั้งต้น (Input)
              </h2>
              <p className="text-[13px] text-stone-500">กรอกข้อมูลพื้นฐาน — ระบบจะใช้สร้างโครงและเขียน</p>
            </div>
            <Separator />
            <div>
              <label className="text-xs font-semibold block mb-1.5">Keyword หลัก *</label>
              <input
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                className="w-full !h-11 rounded-lg border border-stone-200 px-4 outline-none focus:ring-2 focus:ring-amber-200"
                placeholder="เช่น ราคาบอลไหล"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold block mb-1.5">หมวดหมู่</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full h-9 rounded-lg border border-stone-200 px-3 outline-none focus:ring-2 focus:ring-amber-200 bg-white"
                >
                  <option value="ฟุตบอล">⚽ ฟุตบอล</option>
                  <option value="มวย">🥊 มวย</option>
                  <option value="คาสิโน (YMYL)">🎲 คาสิโน (YMYL)</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold block mb-1.5">Search Intent</label>
                <select
                  value={intent}
                  onChange={(e) => setIntent(e.target.value as any)}
                  className="w-full h-9 rounded-lg border border-stone-200 px-3 outline-none focus:ring-2 focus:ring-amber-200 bg-white"
                >
                  <option value="Informational">Informational — ให้ความรู้</option>
                  <option value="Transactional">Transactional</option>
                  <option value="Commercial">Commercial</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold block mb-1.5">รูปแบบเนื้อหา</label>
                <select
                  value={contentType}
                  onChange={(e) => setContentType(e.target.value as any)}
                  className="w-full h-9 rounded-lg border border-stone-200 px-3 outline-none focus:ring-2 focus:ring-amber-200 bg-white"
                >
                  <option value="Knowledge">เนื้อหาความรู้ (Knowledge)</option>
                  <option value="How-to Guide">How-to Guide</option>
                  <option value="Review">รีวิว/เปรียบเทียบ</option>
                </select>
              </div>
            </div>
            <Separator />
            <div>
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <label className="text-xs font-semibold">เลือก AI Model</label>
                <Badge className={`!border ${providerAccent}`}>🔌 API Provider: {providerDisplayName}</Badge>
                {settingsQ.isLoading && <Badge className="!bg-stone-100 !text-stone-600 !border-stone-200 animate-pulse">กำลังโหลดตั้งค่าจากระบบ...</Badge>}
                {!settingsQ.isLoading && !hasLlmKey && (
                  <Badge className="!bg-rose-50 !text-rose-700 !border-rose-200">⚠️ ยังไม่ได้บันทึก LLM API Key (ไปตั้งค่าระบบก่อน)</Badge>
                )}
              </div>
              <p className="text-[12px] text-stone-400 -mt-1 mb-3">
                ✅ รายการโมเดลด้านล่าง = โมเดลของ API Provider ที่บันทึกไว้ในหน้าตั้งค่าระบบ (Settings → LLM) เท่านั้น · 🎯 Default Model + ID ตรงกับ Server llmClient PROVIDER_DEFAULT_MODELS 1:1 · 💲 ราคา $/1M tokens = ราคาประมาณตาม Marketplace อ้างอิง
              </p>
              <div className={`grid grid-cols-1 ${activeModels.length >= 3 ? 'md:grid-cols-3' : activeModels.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-1'} gap-3`}>
                {activeModels.map((m) => (
                  <label
                    key={m.id}
                    className={`border rounded-xl p-4 cursor-pointer transition ${
                      model === m.id
                        ? "border-2 !border-amber-500 bg-amber-50"
                        : "border-stone-200 hover:border-stone-300"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className={`inline-block px-2 py-0.5 rounded-full text-[11px] text-white ${m.cls}`}>{m.badge}</div>
                      <div className="text-[11px] text-stone-400">${m.per1m}/1M tok</div>
                    </div>
                    <div className="text-sm font-semibold mb-1">{m.label}</div>
                    <div className="mt-3">
                      <input
                        type="radio"
                        checked={model === m.id}
                        onChange={() => setModel(m.id)}
                        className="accent-amber-600"
                        disabled={!hasLlmKey}
                      />
                      <span className="ml-2 text-xs text-stone-600">{hasLlmKey ? "เลือกใช้ model นี้" : "ตั้งค่า LLM API Key ก่อน"}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
            <Separator />
            <div>
              <div className="flex items-center gap-2 mb-3">
                <label className="text-xs font-semibold">อัปโหลด Reference DOCX (Optional)</label>
                <Badge className="!bg-emerald-100 !text-emerald-700 !border-emerald-200">📄 Import เร็ว</Badge>
              </div>
              <p className="text-[12px] text-stone-400 -mt-1 mb-3">
                ไฟล์ .docx จาก Microsoft Word / Google Doc → ระบบจะแยก Headings H1-H3, Markdown, URL Sources, FAQ อัตโนมัติ (≤ 8 MB)
              </p>
              <input
                ref={docxFileRef}
                type="file"
                accept=".docx"
                className="hidden"
                onChange={handleDocxUpload}
              />
              <div className="flex flex-wrap items-center gap-3">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => docxFileRef.current?.click()}
                  disabled={extractingDocx}
                  className="!h-10"
                >
                  {extractingDocx ? (
                    <><Loader2 className="size-4 mr-2 animate-spin" />กำลังแปลงไฟล์…</>
                  ) : (
                    <><FileType className="size-4 mr-2" />อัปโหลด Reference DOCX</>
                  )}
                </Button>
                <span className="text-[11px] text-stone-400">
                  Tip: ถ้ามีเนื้อหาเดิม (Word/Google Doc) สามารถอัปโหลดมาแก้ไขต่อได้เลย ไม่ต้องพิมพ์ใหม่
                </span>
              </div>
              {extractingDocx && (
                <div className="kcp-skeleton-shimmer rounded-lg p-4 mt-4 space-y-3">
                  <div className="h-4 bg-stone-200 rounded-md w-3/5"></div>
                  <div className="h-3 bg-stone-200 rounded-md w-4/5"></div>
                  <div className="h-3 bg-stone-200 rounded-md w-2/5"></div>
                </div>
              )}
              {uploadedDoc && !extractingDocx && (
                <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50/50 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <FileType className="size-4 text-emerald-700" />
                    <span className="text-sm font-semibold text-emerald-800">ไฟล์ Reference ที่อัปโหลด</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="!bg-white !border-stone-200 !text-stone-700">
                      📝 {uploadedDoc.fileName}
                    </Badge>
                    <Badge variant="outline" className="!bg-white !border-stone-200 !text-stone-700">
                      💾 {uploadedDoc.fileSizeKB.toLocaleString()} KB
                    </Badge>
                    <Badge variant="outline" className="!bg-white !border-stone-200 !text-stone-700">
                      ✍️ {uploadedDoc.wordCount.toLocaleString()} คำ
                    </Badge>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* STEP 2 OUTLINE + SOURCES */}
      {cur === 1 && (
        <div className="space-y-5">
          <Card className="!rounded-2xl !border !border-stone-200 !bg-white">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <ListOrdered className="size-5 text-amber-700" />2️⃣ โครงเรื่อง (Outline)
              </h2>
              <p className="text-[13px] text-stone-500 -mt-2">AI สร้างโครงจาก keyword + intent — ดู/แก้ก่อนเขียน</p>
              <Separator />
              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant="default"
                  className="!bg-amber-700 hover:!bg-amber-800"
                  onClick={() => aiGenerateOutline(false)}
                  disabled={genOutlineMut.isPending}
                >
                  {genOutlineMut.isPending
                    ? <><Loader2 className="size-4 mr-2 animate-spin" />กำลังสร้าง Outline…</>
                    : <><Wand2 className="size-4 mr-2" />🪄 AI สร้าง Outline</>}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => aiGenerateOutline(true)}
                  disabled={genOutlineMut.isPending}
                >
                  <RefreshCw className={`size-4 mr-2 ${genOutlineMut.isPending ? 'animate-spin' : ''}`} />🔁 สร้างใหม่ (Force)
                </Button>
                <Button size="sm" variant="outline" onClick={() => addOutlineRow(2)}>
                  <Plus className="size-4 mr-2" />+ H2
                </Button>
                <Button size="sm" variant="outline" onClick={() => addOutlineRow(3)}>
                  <Plus className="size-4 mr-2" />+ H3
                </Button>
                <Separator orientation="vertical" className="h-8" />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={toggleSelectAll}
                  className={selectedRows.size === outlineSecs.length ? '!bg-amber-50 !border-amber-300' : ''}
                >
                  {selectedRows.size === outlineSecs.length ? '☑️ ไม่เลือกทั้งหมด' : '⬜ เลือกทั้งหมด'}
                  {selectedRows.size > 0 && <Badge className="!ml-2 !bg-amber-600 !text-white">{selectedRows.size}</Badge>}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={batchDelete}
                  disabled={selectedRows.size === 0}
                  className="!text-rose-700 hover:!bg-rose-50 !border-rose-200 disabled:opacity-40"
                >
                  <Trash2 className="size-4 mr-2" />ลบที่เลือก
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => batchChangeLevel(2)}
                  disabled={selectedRows.size === 0}
                  className="disabled:opacity-40"
                >
                  → H2
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => batchChangeLevel(3)}
                  disabled={selectedRows.size === 0}
                  className="disabled:opacity-40"
                >
                  → H3
                </Button>
              </div>
              <div className="space-y-2">
                {genOutlineMut.isPending ? (
                  <div className="kcp-skeleton-shimmer rounded-xl p-4 space-y-3">
                    <div className="h-10 bg-stone-200 rounded-lg w-full"></div>
                    <div className="h-10 bg-stone-200 rounded-lg w-11/12 ml-4"></div>
                    <div className="h-10 bg-stone-200 rounded-lg w-10/12 ml-4"></div>
                    <div className="h-10 bg-stone-200 rounded-lg w-9/12 ml-8"></div>
                    <div className="h-10 bg-stone-200 rounded-lg w-2/3 ml-8"></div>
                  </div>
                ) : outlineSecs.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-stone-300 bg-stone-50/50 p-8 text-center text-stone-500">
                    <div className="text-[13px] mb-1">ยังไม่มีหัวข้อ Outline</div>
                    <div className="text-[11px] text-stone-400">กดปุ่ม 🪄 AI สร้าง Outline ด้านบน หรือกด + H2 เพิ่มเอง</div>
                  </div>
                ) : outlineSecs.map((sec, i) => {
                  const lvText = `H${sec.heading_level}`;
                  const isH1 = sec.heading_level === 1;
                  const isDragging = dragIdx === i;
                  const isDragOver = dragOverIdx === i;
                  const isSelected = selectedRows.has(i);
                  return (
                    <div
                      key={i}
                      onDragOver={(e) => handleDragOver(e, i)}
                      onDragLeave={handleDragLeave}
                      onDrop={(e) => handleDrop(e, i)}
                      className={`border rounded-xl p-2.5 flex items-center gap-2 transition ${
                        isH1 ? 'bg-amber-50 border-amber-200' : 'bg-stone-50 border-stone-200'
                      } ${isDragging ? 'opacity-50' : ''} ${
                        isDragOver && !isDragging ? 'border-t-4 !border-t-amber-500' : ''
                      } ${isSelected ? '!ring-2 !ring-amber-400' : ''}`}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectRow(i)}
                        className="w-4 h-4 accent-amber-600 shrink-0 cursor-pointer"
                        aria-label={`เลือกแถว ${i + 1}`}
                      />
                      <div
                        draggable
                        onDragStart={(e) => handleDragStart(e, i)}
                        onDragEnd={handleDragEnd}
                        className="cursor-grab active:cursor-grabbing shrink-0 select-none"
                        title="ลากเพื่อจัดลำดับ"
                      >
                        <GripVertical className={`size-4 shrink-0 ${isDragging ? 'text-amber-600' : 'text-stone-400 hover:text-stone-600'}`} aria-hidden />
                      </div>
                      <select
                        value={sec.heading_level}
                        onChange={(e) => setOutlineLevel(i, Number(e.target.value))}
                        className={`h-8 text-[11px] font-bold px-2 rounded-md border-none outline-none cursor-pointer ${isH1 ? 'bg-amber-100 text-amber-800' : 'bg-orange-100 text-orange-800'}`}
                        aria-label={`Heading level row ${i + 1}`}
                      >
                        {[1,2,3,4,5,6].map(n => <option key={n} value={n}>H{n}</option>)}
                      </select>
                      <input
                        value={sec.heading_text}
                        onChange={(e) => setOutlineText(i, e.target.value)}
                        className="flex-1 !h-9 px-3 border border-stone-200 rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-amber-200"
                        placeholder="หัวข้อ..."
                        aria-label={`Outline heading text row ${i + 1}`}
                      />
                      <span className="text-[10px] text-stone-400 hidden sm:block w-14 text-right">
                        ≥{sec.word_target_min} คำ
                      </span>
                      <div className="flex items-center gap-0.5 shrink-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="!h-8 !w-8 !p-0 text-stone-400 hover:text-amber-600 hover:bg-amber-50 disabled:opacity-30"
                          onClick={() => moveOutlineUp(i)}
                          disabled={i === 0}
                          aria-label={`ย้ายหัวข้อขึ้น ${i + 1}`}
                          title="ย้ายขึ้น"
                        >
                          <ChevronUp className="size-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="!h-8 !w-8 !p-0 text-stone-400 hover:text-amber-600 hover:bg-amber-50 disabled:opacity-30"
                          onClick={() => moveOutlineDown(i)}
                          disabled={i === outlineSecs.length - 1}
                          aria-label={`ย้ายหัวข้อลง ${i + 1}`}
                          title="ย้ายลง"
                        >
                          <ChevronDown className="size-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="!h-8 !w-8 !p-0 shrink-0 text-stone-400 hover:text-rose-600 hover:bg-rose-50"
                          onClick={() => delOutlineRow(i)}
                          aria-label={`ลบหัวข้อที่ ${i + 1}`}
                        >
                          <Minus className="size-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="text-[11px] text-stone-400 pt-1">
                📝 {outlineSecs.length} Sections · H1={outlineSecs.filter(s => s.heading_level === 1).length} · H2={outlineSecs.filter(s => s.heading_level === 2).length} · H3+={outlineSecs.filter(s => s.heading_level >= 3).length}
              </div>
            </CardContent>
          </Card>

          <Card className="!rounded-2xl !border !border-emerald-200 !bg-emerald-50/30">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <Search className="size-5 text-emerald-700" />🔍 หา Sources
                  <Badge className="!bg-purple-100 !text-purple-700 !border-purple-200">💜 Sam</Badge>
                </h2>
              </div>
              <p className="text-[13px] text-stone-500 -mt-3">
                ดึงแหล่งอ้างอิงจริงจาก SERP/DataForSEO — จะไปเป็นเอกสารอ้างอิงท้ายบทความ + citation ในเนื้อหา
              </p>
              <div className="space-y-2">
                {sources.map((s, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 p-3 border border-emerald-100 bg-white rounded-lg text-sm"
                  >
                    <span className="text-emerald-600"><CheckCircle2 className="size-4" /></span>
                    <b className="text-stone-800">{s.domain}</b>
                    <span className="text-stone-500">— {s.title}</span>
                    <span className="ml-auto text-xs text-stone-500">DA {s.da}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={refreshSources}
                >
                  {fetchingSources ? <Loader2 className="size-4 mr-2 animate-spin" /> : <RefreshCw className="size-4 mr-2" />}
                  🔄 ดึง Sources ใหม่
                </Button>
                <Button size="sm" variant="outline" className="flex-1">+ เพิ่มแหล่งเอง</Button>
              </div>
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[13px]">
                ✅ พบ 4 แหล่งน่าเชื่อถือ (DA ≥ 35) — แก้ root cause: บทความจะมี citation จริง → EEAT สูงขึ้น
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* STEP 3 WRITE section streaming DYNAMIC from outlineSecs */}
      {cur === 2 && (
        <Card className="!rounded-2xl !border !border-stone-200 !bg-white mb-5">
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Type className="size-5 text-amber-700" />3️⃣ เขียนเนื้อหา ทีละ Section
                <Badge className="!bg-amber-100 !text-amber-800">โปร่งใส · {streamState.phase === 'running' ? (streamState.currentIdx + 1) + '/' + streamState.total : streamState.phase === 'done' ? 'เสร็จสมบูรณ์' : streamState.phase === 'error' ? 'ผิดพลาด' : 'พร้อมเขียน'}</Badge>
              </h2>
              <div className="flex gap-2">
                {streamState.phase !== 'running' && (
                  <Button
                    size="sm"
                    className="!h-9 !bg-emerald-700 hover:!bg-emerald-800 text-white shadow-sm"
                    onClick={() => doRunCreateDraft(false)}
                    disabled={createDraftMut.isPending}
                  >
                    {createDraftMut.isPending ? <Loader2 className="size-4 mr-2 animate-spin" /> : <Sparkles className="size-4 mr-2" />}
                    {streamState.phase === 'done' ? '🔁 เขียนใหม่ (ต่อ)' : '🚀 เริ่มเขียนเนื้อหา Streaming'}
                  </Button>
                )}
                {streamState.phase === 'done' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="!h-9 !bg-amber-50 !text-amber-800 hover:!bg-amber-100"
                    onClick={() => doRunCreateDraft(true)}
                    disabled={createDraftMut.isPending}
                    title="Force regenerate draft ใหม่ทั้งหมด ลบ draft เดิม"
                  >
                    🔁 Force สร้างใหม่
                  </Button>
                )}
                {streamState.phase === 'running' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="!h-9 !bg-rose-50 !text-rose-700 hover:!bg-rose-100"
                    onClick={() => stopStream('error', 'ผู้ใช้ Cancel stream')}
                    title="หยุดการเขียนชั่วคราว (backend จะยังคงทำงานจนจบภายใน — progress เฉพาะฝั่ง UI)"
                  >
                    ⏹️ Abort (Cancel)
                  </Button>
                )}
              </div>
            </div>
            <p className="text-[13px] text-stone-500 -mt-3">
              AI เขียนทีละหัวข้อ ตาม Outline H1-H6 ที่สร้างจาก Step2 — เห็นทุก section ขณะเขียน · ถ้าผิดพลาด retry แค่ section นั้น (force=true regenerate ทั้งหมด)
            </p>
            {/* Overall progress bar */}
            <div>
              <div className="flex justify-between text-[12.5px] mb-1.5">
                <span className="text-stone-600">ความคืบหน้าโดยรวม</span>
                <b className={streamState.phase === 'done' ? 'text-emerald-700' : streamState.phase === 'error' ? 'text-rose-700' : 'text-amber-700'}>
                  {streamState.total ? Math.round(((streamState.phase === 'done' ? streamState.total : streamState.currentIdx + (streamState.phase === 'running' ? 0.5 : 0)) / streamState.total) * 100) : 0}%
                </b>
              </div>
              <div className="h-3.5 rounded-full overflow-hidden bg-stone-200/60">
                <div
                  className={`h-full transition-all duration-700 ${
                    streamState.phase === 'done' ? 'bg-emerald-600' : streamState.phase === 'error' ? 'bg-rose-600' : 'bg-amber-500'
                  }`}
                  style={{ width: `${streamState.total ? Math.min(100, ((streamState.phase === 'done' ? streamState.total : streamState.currentIdx + (streamState.phase === 'running' ? 0.5 : 0)) / streamState.total) * 100) : 0}%` }}
                />
              </div>
            </div>
            <Separator />
            {streamState.phase === 'error' && streamState.errMsg && (
              <div className="p-3 rounded-xl !bg-rose-50 border border-rose-200 text-rose-800 text-[13px]">
                ⚠️ Error: {streamState.errMsg}
              </div>
            )}
            <div className="space-y-3">
              {outlineSecs.filter(s => s.heading_level !== 1).map((sec, idx) => {
                const isDone = streamState.phase === 'done' || idx < streamState.currentIdx;
                const isWriting = streamState.phase === 'running' && idx === streamState.currentIdx;
                const secTitle = sec.heading_text || "Section " + (idx + 1);
                const lvLabel = `H${sec.heading_level}`;
                const bgCol = (sec.heading_level === 2 ? '#fef3c7' : sec.heading_level === 3 ? '#e0f2fe' : '#f5f5f4');
                const bdCol = (sec.heading_level === 2 ? '#fde68a' : sec.heading_level === 3 ? '#bae6fd' : '#e7e5e4');
                return (
                  <div
                    key={`write-sec-${idx}`}
                    className={`border rounded-xl overflow-hidden ${
                      isWriting ? "border-amber-300 shadow-sm shadow-amber-100" : isDone ? "border-emerald-200" : "border-stone-200"
                    }`}
                  >
                    <div
                      className={`p-3 flex items-center justify-between border-b text-sm ${
                        isWriting
                          ? "bg-amber-50 border-amber-200 text-amber-900"
                          : isDone
                            ? "bg-emerald-50 border-emerald-100"
                            : "bg-stone-50 border-stone-200 text-stone-500"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 text-[10.5px] font-bold rounded text-stone-800" style={{ backgroundColor: bgCol, border: `1px solid ${bdCol}` }}>{lvLabel}</span>
                        <b className="truncate">{secTitle}</b>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-[11.5px] text-stone-500 hidden md:inline">เป้าหมาย ≥{sec.word_target_min} คำ</span>
                        <span>
                          {isDone && <span className="text-emerald-700 font-semibold">✓ เสร็จ</span>}
                          {isWriting && (
                            <span className="flex items-center gap-1">
                              <Loader2 className="size-3 mr-1 animate-spin" /> กำลังเขียน...
                            </span>
                          )}
                          {!isDone && !isWriting && <span>รอคิว #{idx + 1}</span>}
                        </span>
                      </div>
                    </div>
                    {(isDone || isWriting) && (
                      <div className="p-4 text-[13.5px] leading-7 text-stone-700 bg-gradient-to-br from-white via-white to-stone-50/40">
                        {bodyMd.split(`## ${secTitle}`)[1]?.split(/^## |^### /m)[0]?.trim() ||
                          (isWriting
                            ? <span className="italic text-stone-500"><Loader2 className="size-3 mr-1.5 inline-block animate-spin" />กำลังเขียนเนื้อหาส่วนนี้ — inject outline key points + 3-tier pillar/longtail/LSI density targets 2% ceiling + citations DA≥35 …</span>
                            : <span className="italic text-stone-500">ไม่พบเนื้อหา section ใน markdown body — กด "เริ่มเขียน" หรือแก้ไข Outline ก่อน</span>)}
                      </div>
                    )}
                  </div>
                );
              })}
              {outlineSecs.filter(s => s.heading_level !== 1).length === 0 && (
                <div className="p-6 text-center text-stone-500 text-[13px] border border-dashed border-stone-300 rounded-xl bg-stone-50/50">
                  ⚠️ Outline Step2 ยังไม่มี sections H2+ กลับไป Step2 แล้วกด AI Generate Outline ก่อน
                </div>
              )}
            </div>
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-[13px]">
              🛡️ Hard Safety: retry สูงสุด 2 ครั้ง/section backend fallback static · เจอ 402 (เครดิตหมด) → หยุดทันที ไม่เผาเครดิต · Backend inject 3 context: <b>3-tier hierarchy Pillar→Cluster→Supporting keywords</b> + <b>Step2 Outline (H1-H6 user edited)</b> + <b>Density targets (max {DENSITY_PCT_MAX}% Main/Longtail/LSI spread)</b> — จึงเป็น EEAT สูง
            </div>
          </CardContent>
        </Card>
      )}

      {/* STEP 4 ASSEMBLE + Meta LENGTH GUARDS 60/160 chars */}
      {cur === 3 && (
        <Card className="!rounded-2xl !border !border-sky-200 !bg-sky-50/30 mb-5">
          <CardContent className="p-6 space-y-4">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Sparkles className="size-5 text-sky-700" />4️⃣ รวม + Meta (Assemble)
            </h2>
            <p className="text-[13px] text-stone-500 -mt-2">รวมทุก section เป็นบทความเดียว + กรอก/แก้ Meta · LENGTH COLOR RULE: Title 30-60 = ✓เขียว, Description 120-320 = ✓เขียว</p>
            <Separator />
            <div className="space-y-4 text-sm">
              <div className="flex items-center gap-2 p-3 bg-white border border-stone-200 rounded-md">
                <CheckCircle2 className="text-emerald-600 size-4 shrink-0" />
                <span>รวม {outlineSecs.filter(s=>s.heading_level!==1).length} section → 1 บทความ (<b>{wordCount.toLocaleString()}</b> คำ)</span>
                {ymylInjected && <Badge className="!ml-2 !bg-rose-100 !text-rose-700 !border-rose-200">🛡️ YMYL Disclaimer: ON</Badge>}
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[12.5px] pl-1 pr-1">
                  <label className="font-semibold text-stone-700">Meta Title (ชื่อหน้า SERP Google)</label>
                  <span className={mt.length >= 30 && mt.length <= 60 ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                    <b>{mt.length}</b>/60 ตัวอักษร{mt.length >= 30 && mt.length <= 60 ? ' ✓ Optimal' : ' (เป้าหมาย 30-60)'}
                  </span>
                </div>
                <input
                  value={mt}
                  onChange={(e) => setMt(e.target.value.slice(0, 120))}
                  placeholder='เช่น ราคาบอลไหล วันนี้ คืออะไร สอนดูตารางบอล 2569'
                  className="w-full !h-11 px-4 rounded-lg border border-stone-200 bg-white text-sm outline-none focus:ring-2 focus:ring-sky-200"
                  maxLength={120}
                />
                <div className="h-2.5 rounded-full overflow-hidden bg-stone-200/70">
                  <div className={`h-full transition-all ${mt.length >= 30 && mt.length <= 60 ? 'bg-emerald-600' : 'bg-amber-500'}`} style={{ width: `${Math.min(100, (mt.length / 60) * 100)}%` }} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[12.5px] pl-1 pr-1">
                  <label className="font-semibold text-stone-700">Meta Description (คำบรรยาย SERP)</label>
                  <span className={mdes.length >= 120 && mdes.length <= 320 ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                    <b>{mdes.length}</b>/320 ตัวอักษร{mdes.length >= 120 && mdes.length <= 320 ? ' ✓ Optimal' : ' (เป้าหมาย 120-320)'}
                  </span>
                </div>
                <textarea
                  value={mdes}
                  onChange={(e) => setMdes(e.target.value.slice(0, 400))}
                  rows={3}
                  placeholder='อธิบายสั้นๆ เกี่ยวกับเนื้อหาบทความ — ควรมี Keyword หลักอยู่ 1-2 ครั้ง และสะท้อน Search Intent ให้ชัดเจน'
                  className="w-full px-4 py-2.5 rounded-lg border border-stone-200 bg-white text-sm outline-none focus:ring-2 focus:ring-sky-200 resize-none"
                  maxLength={400}
                />
                <div className="h-2.5 rounded-full overflow-hidden bg-stone-200/70">
                  <div className={`h-full transition-all ${mdes.length >= 120 && mdes.length <= 320 ? 'bg-emerald-600' : 'bg-amber-500'}`} style={{ width: `${Math.min(100, (mdes.length / 320) * 100)}%` }} />
                </div>
              </div>
              <div className="flex items-center gap-2 p-3 bg-white border border-stone-200 rounded-md">
                <CheckCircle2 className="text-emerald-600 size-4 shrink-0" />
                <span>Clean markdown (H1..H6 structure 100% no # หลุด) · EEAT Score: <b className="text-emerald-700">{eeatEst}/100</b></span>
              </div>
            </div>
            <Separator />
            <div className="p-4 rounded-xl bg-sky-100 border border-sky-200 text-[13px]">
              <div className="text-[11px] font-semibold text-sky-700 uppercase tracking-wide mb-1">👀 SERP Preview (Google)</div>
              <div className="text-[15px] font-bold text-sky-800 mb-1 leading-snug">{mt || <span className="text-sky-400 italic">Meta Title ยังไม่ถูกตั้งค่า</span>}</div>
              <div className="text-[11px] text-emerald-700 mb-2 truncate">thaiaeo.manus.host › blog › {keyword ? keyword.replace(/\s+/g, '-').slice(0,80) : 'article-slug'}</div>
              <div className="text-[13px] text-stone-700 leading-snug">
                {mdes || <span className="text-stone-400 italic">Meta Description ยังไม่ถูกตั้งค่า — คำบรรยายจะปรากฏตรงนี้บนหน้าผลการค้นหา Google</span>}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* STEP 5 REVIEW + KEYWORD DENSITY GAUGE */}
      {cur === 4 && (() => {
        const parsedSections = parseBodyMdIntoSections(bodyMd);
        return (
        <div className="space-y-5">
          <Card className="!rounded-2xl !border !border-stone-200 !bg-white">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <BookCheck className="size-5 text-amber-700" />5️⃣ ตรวจ/แก้ไข (Per-Section Inline Editor + ✨ AI Rewrite)
              </h2>
              <p className="text-[13px] text-stone-500 -mt-2">แยกแก้ไขทีละส่วน (ตาม H2/H3) · กด ✨ AI เขียนใหม่ เพื่อปรับแต่งย่อหน้าแต่ละอันอิสระกัน</p>
              <Separator />
              <div className="flex gap-2 flex-wrap mb-3">
                <Button variant="outline" size="sm" className="!h-8 !text-[12px] !px-3"><b>B</b></Button>
                <Button variant="outline" size="sm" className="!h-8 !text-[12px] !px-3 italic"><i>I</i></Button>
                <Button variant="outline" size="sm" className="!h-8 !text-[12px] !px-3">H2</Button>
                <Button variant="outline" size="sm" className="!h-8 !text-[12px] !px-3">H3</Button>
                <Button variant="outline" size="sm" className="!h-8 !text-[12px] !px-3">• List</Button>
                <Button variant="outline" size="sm" className="!h-8 !text-[12px] !px-3">🔗 Link</Button>
                <Button
                  size="sm"
                  className="!h-8 !text-[12px] !px-3 !bg-amber-700 hover:!bg-amber-800 text-white"
                  disabled={rewriteSectionMut.isPending || !draftId || parsedSections.length === 0}
                  onClick={() => {
                    const firstContentIdx = parsedSections.findIndex(s => s.headingLevel >= 2);
                    doRewriteSection(firstContentIdx >= 0 ? firstContentIdx : 0);
                  }}
                  title="เขียนใหม่ย่อหน้าแรก (H2 Section แรก)"
                >
                  {rewritingSectionIdx !== null && (parsedSections.findIndex(s => s.headingLevel >= 2) === rewritingSectionIdx || rewritingSectionIdx === 0) ? (
                    <><Loader2 className="size-3.5 mr-1.5 animate-spin" />กำลัง AI เขียนใหม่…</>
                  ) : (
                    <><Sparkles className="size-3.5 mr-1.5" />↺ AI เขียนใหม่ย่อหน้าแรก</>
                  )}
                </Button>
              </div>

              {/* PER-SECTION CARDS (H2 wrapper + inline textarea + ✨ AI Rewrite button per section) */}
              <div className="space-y-3">
                {parsedSections.length === 0 && (
                  <div className="p-6 text-center text-stone-500 text-[13px] border border-dashed border-stone-300 rounded-xl bg-stone-50/50">
                    ไม่พบเนื้อหาบทความ — กลับไป Step 3 เขียนเนื้อหาก่อน
                  </div>
                )}
                {parsedSections.map((sec, sIdx) => {
                  const isH1 = sec.headingLevel === 1;
                  const isH2 = sec.headingLevel === 2;
                  const isH3 = sec.headingLevel === 3;
                  const isIntro = sec.headingLevel === 0;
                  const lvLabel = sec.headingLevel > 0 ? `H${sec.headingLevel}` : 'INTRO';
                  const bgCol = isH1 ? '#fef3c7' : isH2 ? '#dbeafe' : isH3 ? '#ecfdf5' : '#f5f5f4';
                  const bdCol = isH1 ? '#fde68a' : isH2 ? '#93c5fd' : isH3 ? '#6ee7b7' : '#e7e5e4';
                  const txtCol = isH1 ? 'text-amber-900' : isH2 ? 'text-sky-900' : isH3 ? 'text-emerald-900' : 'text-stone-700';
                  const isRewriting = rewritingSectionIdx === sIdx;
                  return (
                    <div
                      key={`sec-card-${sIdx}`}
                      className={`border rounded-xl overflow-hidden shadow-sm ${
                        isRewriting ? 'border-amber-400 ring-2 ring-amber-200' :
                        isH2 ? 'border-sky-200' :
                        isH1 ? 'border-amber-200' :
                        isH3 ? 'border-emerald-200' :
                        'border-stone-200'
                      }`}
                    >
                      <div
                        className={`p-2.5 flex items-center justify-between border-b ${txtCol}`}
                        style={{ backgroundColor: bgCol, borderColor: bdCol }}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className="px-2 py-0.5 text-[10.5px] font-bold rounded text-stone-800 shrink-0"
                            style={{ backgroundColor: 'rgba(255,255,255,0.7)', border: `1px solid ${bdCol}` }}
                          >
                            {lvLabel}
                          </span>
                          <b className="truncate text-[13.5px]">{sec.heading}</b>
                        </div>
                        <div className="flex items-center gap-2 shrink-0 ml-2">
                          <span className="hidden sm:inline-block text-[10.5px] opacity-70 mr-1">
                            ~{estimateWordCount(sec.body)} คำ
                          </span>
                          <Button
                            size="sm"
                            variant={isH2 || !isIntro ? "default" : "outline"}
                            className={
                              (isH2 || !isIntro)
                                ? "!h-8 !text-[11.5px] !px-3 !bg-gradient-to-r !from-amber-600 !to-orange-600 hover:!from-amber-700 hover:!to-orange-700 text-white shadow-sm"
                                : "!h-8 !text-[11.5px] !px-3"
                            }
                            disabled={rewriteSectionMut.isPending || !draftId}
                            onClick={() => doRewriteSection(sIdx)}
                          >
                            {isRewriting ? (
                              <><Loader2 className="size-3.5 mr-1.5 animate-spin" />กำลังเขียนใหม่…</>
                            ) : (
                              <><Sparkles className="size-3.5 mr-1.5" />AI เขียนใหม่ย่อหน้านี้</>
                            )}
                          </Button>
                        </div>
                      </div>
                      <div className="p-3 bg-white">
                        {sec.headingLevel > 0 && (
                          <div
                            className={`font-bold mb-2 pb-1 border-b border-stone-100 ${
                              sec.headingLevel === 1 ? 'text-[22px] mt-1' :
                              sec.headingLevel === 2 ? 'text-[18px] mt-0.5' :
                              sec.headingLevel === 3 ? 'text-[15px] mt-0.5' :
                              'text-[14px]'
                            }`}
                          >
                            {'#'.repeat(sec.headingLevel)} {sec.heading}
                          </div>
                        )}
                        <textarea
                          value={sec.body}
                          onChange={(e) => {
                            const newMd = replaceSectionInBodyMd(bodyMd, sIdx, e.target.value);
                            setBodyMd(newMd);
                          }}
                          className={`w-full p-3 border border-stone-200 rounded-lg font-serif text-[14.5px] leading-8 outline-none focus:ring-2 focus:ring-amber-200 resize-y transition-colors ${
                            isRewriting ? 'bg-amber-50/60 border-amber-200' : ''
                          } ${isIntro ? 'min-h-[110px]' : isH1 ? 'min-h-[110px]' : isH2 ? 'min-h-[220px]' : 'min-h-[140px]'}`}
                          placeholder={`เนื้อหาส่วนนี้...`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <Separator />
              <details className="text-[12.5px]">
                <summary className="cursor-pointer select-none text-stone-600 hover:text-amber-800 font-medium">
                  ⚙️ Raw Markdown Editor (ซ่อนโดยปริยาย — สำหรับมือโปรต้องการแก้ # และโครงสร้างโดยตรง)
                </summary>
                <div className="mt-2">
                  <textarea
                    value={bodyMd}
                    onChange={(e) => setBodyMd(e.target.value)}
                    className="w-full min-h-[220px] p-3 border border-stone-200 rounded-xl font-mono text-[12.5px] leading-7 outline-none focus:ring-2 focus:ring-amber-200 bg-stone-50"
                  />
                </div>
              </details>
            </CardContent>
          </Card>

          {/* KEYWORD DENSITY PANEL — Core SA L245-L266 */}
          <Card
            className={`!rounded-2xl !border p-4 space-y-2 mb-5 ${
              densityPass
                ? "!border-emerald-200 !bg-emerald-50/30"
                : "!border-rose-200 !bg-rose-50/40 !text-rose-800"
            }`}
          >
            <CardContent className="p-2 space-y-4">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <Hash className="size-5 text-emerald-700" />📊 Keyword Density (เพดาน ≤ {DENSITY_PCT_MAX}%)
                </h2>
              </div>
              <div className="flex items-center justify-between text-[13px] mb-2">
                <span>จำนวนคำบทความ: <b>{wordCount.toLocaleString()} คำ</b></span>
                <span>เพดาน {DENSITY_PCT_MAX}% = <b>{ceilingMax} ครั้ง</b></span>
              </div>
              <div className="h-3.5 rounded-full overflow-hidden border border-white/60 bg-stone-200/50">
                <div
                  className={`h-full transition ${densityPass ? "bg-emerald-600" : "bg-rose-600"}`}
                  style={{ width: `${Math.min(100, (kwTotalDemo / ceilingMax) * 100)}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[12px] mt-1">
                <span className={`font-semibold ${densityPass ? "text-emerald-700" : "text-rose-700"}`}>
                  {densityPass
                    ? "✓ ใช้จริงรวม 37 ครั้ง (1.7%) — ไม่เกินเพดาน"
                    : "⚠ ใช้เกินเพดาน → ต้องลดการใช้ซ้ำ"}
                </span>
                <span className="text-stone-500">เหลืออีก {Math.max(0, ceilingMax - kwTotalDemo)} ครั้ง</span>
              </div>
              <Separator />
              <div className="space-y-1.5 text-[12.5px] leading-[2em]">
                {densityRows.map((r, i) => (
                  <div key={i} className="flex items-center gap-2">
                    {r.pass ? (
                      <CheckCircle2 className="text-emerald-600 size-4 shrink-0" />
                    ) : (
                      <AlertTriangle className="text-rose-600 size-4 shrink-0" />
                    )}
                    <b className="text-stone-800">{r.kw}</b>
                    <span className="text-[11px] text-stone-400">
                      ({r.type === "main" ? "คีย์หลัก" : r.type === "longtail" ? "long-tail" : "LSI"})
                    </span>
                    <span className="ml-auto text-stone-500">{r.count} ครั้ง</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[12.5px] text-amber-900">
            📐 <b>กฎ:</b> keyword ทั้งหมด (หลัก+รอง+LSI) รวมกัน <b>ไม่เกิน {DENSITY_PCT_MAX}%</b> ของจำนวนคำ — เป็นเพดานกันยัด ไม่ใช่เป้าที่ต้องถึง (ใช้น้อยกว่าแต่อ่านลื่น = ดีกว่า)
          </div>

          {/* KEYWORD PLACEMENT CHECKLIST 5-POINT */}
          <Card className="!rounded-2xl !border !border-purple-200 !bg-purple-50/30 mb-5">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <Sparkles className="size-5 text-purple-700" />🎯 Keyword Placement Checklist
                </h2>
                <Badge className={`${placementChecklist.filter(p=>p.ok).length===5 ? '!bg-emerald-600 !text-white' : '!bg-amber-500 !text-white'}`}>
                  {placementChecklist.filter(p=>p.ok).length}/{placementChecklist[0]?.total || 5} ตรง
                </Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[13px]">
                {placementChecklist.map((p, i) => (
                  <div key={p.id || i} className={`flex items-start gap-2 p-2.5 rounded-lg border ${p.ok ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'}`}>
                    {p.ok ? (
                      <CheckCircle2 className="text-emerald-600 size-4 shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle className="text-amber-600 size-4 shrink-0 mt-0.5" />
                    )}
                    <span className={p.ok ? 'text-emerald-800' : 'text-amber-800'}>{p.label}</span>
                  </div>
                ))}
              </div>
              <div className="text-[11.5px] text-purple-700 bg-white/70 rounded-lg p-2 border border-purple-100">
                💡 <b>Tip:</b> ครบ 5/5 → Google เข้าใจเรื่องราวของบทความชัดเจนขึ้น · Ranking ดีขึ้น · ลดการถูก de-index จากการยัด keyword ไม่สมเหตุสมผล
              </div>
            </CardContent>
          </Card>

          {/* References list */}
          <Card className="!rounded-2xl !border !border-emerald-200 !bg-emerald-50/40">
            <CardContent className="p-6 space-y-2">
              <h2 className="text-lg font-bold flex items-center gap-2 mb-1">
                <BookCheck className="size-5 text-emerald-700" />📚 เอกสารอ้างอิง
              </h2>
              <Separator />
              <ol className="text-[13px] text-stone-700 leading-loose pl-6 list-decimal">
                {sources.map((s, i) => (
                  <li key={i} className="mb-1">
                    {s.domain.charAt(0).toUpperCase() + s.domain.slice(1)} —{" "}
                    <a href="#" className="text-sky-700 underline underline-offset-2">{s.title}</a>
                  </li>
                ))}
              </ol>
              <div className="p-3 rounded-lg bg-emerald-100 border border-emerald-200 mt-4 text-sm">
                ✅ <b className="text-emerald-800">เอกสารอ้างอิง 4 แหล่ง</b> ดึงอัตโนมัติจากขั้นหา Sources (SERP/DataForSEO)
              </div>
            </CardContent>
          </Card>
        </div>
        )})()}

      {/* STEP 6 PREVIEW — SA blueprint L286-L334 */}
      {cur === 5 && (
        <div className="space-y-5">
          <Card className="!rounded-2xl !border !border-stone-200 !bg-white">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Eye className="size-5 text-amber-700" />6️⃣ ดูตัวอย่างก่อนบันทึก (Preview)
              </h2>
              <Separator />
              <div className="p-4 border border-stone-200 rounded-xl bg-white">
                <div className="text-[11px] text-stone-400 mb-1">🔍 SEO Preview — หน้าตาบน Google</div>
                <div className="text-[17px] text-[#1a0dab] leading-tight mt-1 mb-0.5">{mt || <span className="text-stone-400 italic">Meta Title ยังไม่ถูกตั้งค่า</span>}</div>
                <div className="text-[12.5px] text-[#006621]">thaiaeo.manus.host › บทความ › {(keyword || "article-slug").trim().replace(/\s+/g, "-").slice(0, 90)}</div>
                <div className="text-[12.5px] text-[#4d5156] leading-snug mt-1">{mdes || <span className="text-stone-400 italic">Meta Description ยังไม่ถูกตั้งค่า</span>}</div>
              </div>
              <Separator />
              <div className="border border-stone-200 rounded-xl overflow-hidden">
                <div className="p-3 bg-stone-50 border-b border-stone-200 flex gap-4 text-xs text-stone-500 flex-wrap">
                  <span>📄 {wordCount.toLocaleString()} คำ</span>
                  <span>🔑 density {demoPctRounded}% ✓</span>
                  <span>📚 อ้างอิง 4 แหล่ง</span>
                  <span>⏱ อ่าน 8 นาที</span>
                </div>
                <div className="p-6 max-h-[340px] overflow-auto">
                  <article
                    className="prose prose-stone max-w-none"
                    dangerouslySetInnerHTML={{ __html: renderMdSafe(bodyMd || "") }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="!rounded-2xl !border !border-stone-200 !bg-white">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="text-sm font-semibold">สถานะ:</span>
                <select
                  className="rounded-lg border border-stone-200 p-1.5"
                  defaultValue="done"
                >
                  <option value="draft">📝 ร่าง</option>
                  <option value="done">✅ เสร็จ (พร้อมใช้)</option>
                </select>
                <span className="text-[11px] text-stone-400">บันทึกเข้าคลัง เพื่อส่งมอบลูกค้า</span>
              </div>

              <div className="p-4 rounded-xl border border-sky-200 bg-sky-50/50 space-y-3">
                <div className="flex items-center gap-2">
                  <CalendarDays className="size-5 text-sky-700" />
                  <h3 className="font-semibold text-sky-900">⏰ ตั้งเวลาเผยแพร่อัตโนมัติ (CRON Worker ทุก 1 นาที)</h3>
                </div>
                <p className="text-[12.5px] text-sky-700 -mt-1">เลือกวันที่ + เวลา → ระบบจะเผยแพร่ให้อัตโนมัติเมื่อถึงเวลานั้น (เก็บใน outlineJson.__scheduled_at ไม่ต้อง ALTER DB — AC-6 compliant)</p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="flex-1 flex items-center gap-2">
                    <Clock className="size-4 text-stone-500 shrink-0" />
                    <input
                      type="datetime-local"
                      value={scheduledDateTime}
                      onChange={(e) => setScheduledDateTime(e.target.value)}
                      className="flex-1 !h-10 rounded-lg border border-stone-200 px-3 outline-none focus:ring-2 focus:ring-sky-200 bg-white text-sm"
                      min={new Date(Date.now() + 120_000).toISOString().slice(0, 16)}
                    />
                  </div>
                  <Button
                    size="sm"
                    className="!h-10 !bg-sky-700 hover:!bg-sky-800 shrink-0"
                    onClick={doSetSchedule}
                    disabled={setScheduleMut.isPending || !draftId || !scheduledDateTime}
                  >
                    {setScheduleMut.isPending
                      ? <><Loader2 className="size-4 mr-2 animate-spin" />กำลังตั้งเวลา…</>
                      : <><CalendarDays className="size-4 mr-2" />ตั้งเวลาเผยแพร่</>}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="!h-10 shrink-0"
                    onClick={doCancelSchedule}
                    disabled={setScheduleMut.isPending || !draftId || !scheduledDateTime}
                  >
                    <X className="size-4 mr-2" />ยกเลิก
                  </Button>
                </div>
                {scheduledDateTime && (
                  <div className="text-[12px] text-sky-800 bg-white/70 rounded-lg px-3 py-2 border border-sky-100">
                    📅 ตารางเวลาที่ตั้ง: <b>{new Date(scheduledDateTime).toLocaleString('th-TH', { dateStyle: 'full', timeStyle: 'long' })}</b>
                    <span className="text-sky-600 ml-2">(ระบบจะเผยแพร่ให้อัตโนมัติในนาทีแรกหลังถึงเวลา)</span>
                  </div>
                )}
              </div>

              <Separator />
              <div className="flex gap-2 flex-wrap">
                <Button
                  className="!bg-amber-700 hover:!bg-amber-800"
                  onClick={() => doPublish(false)}
                  disabled={publishMut.isPending || !draftId}
                >
                  {publishMut.isPending
                    ? <><Loader2 className="size-4 mr-2 animate-spin" />กำลังเผยแพร่…</>
                    : <><Save className="size-4 mr-2" />✨ เผยแพร่ทันที (Publish)</>}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => doPublish(true)}
                  disabled={publishMut.isPending || !draftId}
                >
                  🔒 เลิกเผยแพร่
                </Button>
                <div className="flex gap-2 flex-1 flex-wrap">
                  <Button variant="outline" className="flex-1 min-w-[120px]"
                    onClick={() => {
                      const blob = new Blob([bodyMd || ''], { type: 'text/markdown;charset=utf-8' });
                      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `article_${draftId || 'draft'}_${Date.now()}.md`; a.click();
                      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
                      toast.success("⬇ ดาวน์โหลด Markdown เสร็จ");
                    }}
                  >
                    <FileDown className="size-4 mr-2" />⬇ Markdown
                  </Button>
                  <Button variant="outline" className="flex-1 min-w-[120px]"
                    onClick={() => {
                      const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${mt||keyword}</title><meta name="description" content="${mdes||''}"></head><body>${renderMdSafe(bodyMd||'')}</body></html>`;
                      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
                      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `article_${draftId || 'draft'}_${Date.now()}.html`; a.click();
                      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
                      toast.success("⬇ ดาวน์โหลด HTML เสร็จ");
                    }}
                  >
                    <FileText className="size-4 mr-2" />⬇ HTML
                  </Button>
                  <Button variant="outline" className="flex-1 min-w-[120px]"
                    onClick={async () => {
                      const t = toast.loading("กำลังสร้างไฟล์ Word (.docx)...");
                      try {
                        const blob = await generateDocxBlob(bodyMd || '', mt || keyword);
                        const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `article_${draftId || 'draft'}_${Date.now()}.docx`; a.click();
                        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
                        toast.dismiss(t); toast.success("📄 ดาวน์โหลด Word (.docx) เสร็จ");
                      } catch (e: any) { toast.dismiss(t); toast.error("สร้างไฟล์ Word ล้มเหลว: " + String(e?.message || e).slice(0, 100)); }
                    }}
                  >
                    <FileType className="size-4 mr-2" />📄 Word (.docx)
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

        </main>

        {/* ── 3-TIER CONTEXT SIDEBAR (KCP → /write PIPELINE PASS-THRU) ──
             ผู้ใช้ VERBATIM: คลิกเขียน ระบบต้องดึงคีย์ชุดนั้นไปที่หน้าเขียน เพื่อเตรียมเริ่มเขียน
             Pillar H1 / Cluster / Focus keyword H3·คีย์ลอง / Siblings list / กฎการวางคำ */}
        <aside className="lg:col-span-4 space-y-4">
          {q.data?.cluster_context && (
            <Card className="!rounded-2xl !border !border-amber-200 !bg-amber-50/40 shadow-[0_1px_0_rgba(0,0,0,0.03)]">
              <CardContent className="p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-100 to-emerald-100 grid place-items-center"><Target className="size-6 text-amber-700" /></div>
                  <div className="flex-1">
                    <p className="text-[11px] uppercase tracking-wider text-stone-500 mb-0.5">โครงคำสำคัญ 3 ระดับ (จาก KCP)</p>
                    <p className="text-[15px] font-bold text-stone-900">นำทาง H1 / H2 / H3</p>
                  </div>
                </div>

                {q.data.cluster_context.pillar_keyword && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold" style={{ backgroundColor: '#fff7ed', color: '#92400e', border: '1px solid #b45309' }} title="บทความ Focus · Meta Title/Desc">H1 · Pillar</span>
                      <b className="text-[13px] text-stone-800 flex-1 break-words min-w-0">{q.data.cluster_context.pillar_keyword.keyword}</b>
                      <span className="text-[10px] text-stone-400 tabular-nums">#{q.data.cluster_context.pillar_keyword.id}</span>
                    </div>
                  </div>
                )}

                {q.data.cluster_context.cluster?.name && (
                  <div className="px-3 py-2 rounded-lg bg-white border border-amber-200/60">
                    <p className="text-[10px] uppercase tracking-wider text-stone-500 mb-1">กลุ่ม Cluster</p>
                    <p className="text-[13px] font-semibold text-stone-800 break-words">{q.data.cluster_context.cluster.name}</p>
                  </div>
                )}

                {q.data.cluster_context.focus_keyword && (
                  <div className="p-3 rounded-xl bg-white border-2 border-emerald-300 shadow-sm">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      {(() => {
                        const t = String(q.data.cluster_context.focus_keyword.tier ?? 'supporting');
                        const st: any =
                          t === 'pillar' ? { bg: '#fff7ed', color: '#92400e', border: '#b45309', heading: 'H1', desc: 'บทความ Focus' }
                          : t === 'cluster' ? { bg: '#eff6ff', color: '#1d4ed8', border: '#2563eb', heading: 'H2', desc: 'หัวข้อหลัก / Intro' }
                          : { bg: '#ecfdf5', color: '#047857', border: '#059669', heading: 'H3', desc: 'Body · Img · FAQ' };
                        return (
                          <>
                            <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold" style={{ backgroundColor: st.bg, color: st.color, border: `1px solid ${st.border}` }} title={st.desc}>{st.heading} · {t === 'pillar' ? 'Pillar' : t === 'cluster' ? 'Cluster' : 'คีย์ลอง'} ✓ คำนี้</span>
                            <span className="text-[10px] uppercase tracking-wider text-emerald-700 font-bold ml-auto">บทความปัจจุบัน</span>
                          </>
                        );
                      })()}
                    </div>
                    <p className="text-[14px] font-bold text-stone-900 break-words">{q.data.cluster_context.focus_keyword.keyword}</p>
                    <div className="flex items-center gap-2 mt-2 flex-wrap text-[10.5px] text-stone-500">
                      {q.data.cluster_context.focus_keyword.intent && (
                        <span className="px-2 py-0.5 rounded bg-stone-100 border border-stone-200 text-stone-600">Intent: {mapIntentUiLabel(q.data.cluster_context.focus_keyword.intent)}</span>
                      )}
                      {(typeof q.data.cluster_context.focus_keyword.kd === 'number' && Number.isFinite(q.data.cluster_context.focus_keyword.kd)) && (
                        <span className="px-2 py-0.5 rounded bg-rose-50 border border-rose-200 text-rose-700">KD {Math.round(Number(q.data.cluster_context.focus_keyword.kd))}%</span>
                      )}
                      {(typeof q.data.cluster_context.focus_keyword.sv === 'number' && Number.isFinite(q.data.cluster_context.focus_keyword.sv)) && (
                        <span className="px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-700">Vol {Number(q.data.cluster_context.focus_keyword.sv).toLocaleString()}</span>
                      )}
                    </div>
                  </div>
                )}

                {Array.isArray(q.data.cluster_context.same_cluster_keywords) && q.data.cluster_context.same_cluster_keywords.length > 1 && (
                  <div className="space-y-2">
                    <p className="text-[11px] uppercase tracking-wider text-stone-500 font-semibold">คำอื่นๆ ในกลุ่มเดียว ({q.data.cluster_context.same_cluster_keywords.length} คำ)</p>
                    <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
                      {q.data.cluster_context.same_cluster_keywords.map((sk: any, i: number) => {
                        const t = String(sk.tier ?? 'supporting');
                        const st: any =
                          t === 'pillar' ? { bg: '#fff7ed', color: '#92400e', border: '#b45309', heading: 'H1' }
                          : t === 'cluster' ? { bg: '#eff6ff', color: '#1d4ed8', border: '#2563eb', heading: 'H2' }
                          : { bg: '#ecfdf5', color: '#047857', border: '#059669', heading: 'H3' };
                        const isFocus = q.data?.cluster_context?.focus_keyword && Number(sk.id) === Number(q.data.cluster_context.focus_keyword.id);
                        return (
                          <div key={sk.id ?? i} className={`flex items-center gap-2 p-2 rounded-lg border ${isFocus ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-stone-200'}`}>
                            <span className="shrink-0 inline-flex items-center rounded px-1.5 py-0.5 text-[9.5px] font-bold" style={{ backgroundColor: st.bg, color: st.color, border: `1px solid ${st.border}` }}>{st.heading}</span>
                            <span className={`text-[12px] flex-1 break-words min-w-0 ${isFocus ? 'font-semibold text-emerald-800' : 'text-stone-700'}`}>{sk.keyword}</span>
                            {isFocus && <CheckCircle2 className="size-3.5 shrink-0 text-emerald-600" />}
                          </div>
                        );
                      })}
                    </div>
                    <p className="text-[10.5px] leading-5 text-stone-500 mt-1">
                      💡 <b>กฎการวางคำ:</b> Pillar (H1) = บทความหลัก / Cluster (H2) = หัวข้อ Section / Supporting (H3) = ย่อย + ภาพ + FAQ · เขียน H1 1 ครั้ง / H2 1-2 ครั้งต่อคำ / H3 2-4 ครั้งต่อคำ
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </aside>
      </div>
    </MainDashboardShell>
  );
}
